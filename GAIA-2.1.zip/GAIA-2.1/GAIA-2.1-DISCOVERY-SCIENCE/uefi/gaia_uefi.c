#include "gaia_uefi.h"
#include "gaia_machine_core.h"
#include "gaia_metal.h"

/* MS/COFF floating-point marker; no CRT or libm is required. */
int _fltused=0;

/* GAIA DISCOVERY SCIENCE UEFI 2.1
   Freestanding x86-64 UEFI development shell. No libc, CRT, Win32 or OS.
   DNA is a first-class machine value beside integers, pointers and raw code. */
void *memcpy(void*d,const void*s,unsigned long long n){u8*dd=(u8*)d;const u8*ss=(const u8*)s;for(unsigned long long i=0;i<n;i++)dd[i]=ss[i];return d;}
void *memset(void*d,int v,unsigned long long n){u8*dd=(u8*)d;for(unsigned long long i=0;i<n;i++)dd[i]=(u8)v;return d;}

static EFI_HANDLE gImage;
static EFI_SYSTEM_TABLE *gST;
static EFI_BOOT_SERVICES *gBS;
static EFI_FILE_PROTOCOL *gRoot;
static UINTN gCols=80,gRows=25;
static int gExit=0,gLines=1;
static char gSource[32768];
static int gSourceN=0;
static D3Program gProg;
static d_u8 gMetal[DM_MAX],gCoff[DM_MAX+128];

static void attr(UINTN a){gST->ConOut->SetAttribute(gST->ConOut,a);}
static void pos(UINTN x,UINTN y){gST->ConOut->SetCursorPosition(gST->ConOut,x,y);}
static void clear_screen(void){gST->ConOut->ClearScreen(gST->ConOut);}
static int slen(const char*s){int n=0;while(s&&s[n])n++;return n;}
static int seq(const char*a,const char*b){int i=0;for(;;i++){if(a[i]!=b[i])return 0;if(!a[i])return 1;}}
static int prefix(const char*s,const char*p){int i=0;while(p[i]){if(s[i]!=p[i])return 0;i++;}return 1;}
static d_u64 parse_u64(const char*s){d_u64 v=0;int i=0,base=10;while(s[i]==' '||s[i]=='\t')i++;if(s[i]=='0'&&(s[i+1]=='x'||s[i+1]=='X')){base=16;i+=2;}for(;;i++){int d=-1;char c=s[i];if(c>='0'&&c<='9')d=c-'0';else if(c>='a'&&c<='f')d=10+c-'a';else if(c>='A'&&c<='F')d=10+c-'A';if(d<0||d>=base)break;v=v*(d_u64)base+(d_u64)d;}return v;}

static void raw_ascii(const char*s){CHAR16 w[384];int n=0;while(*s){char c=*s++;if(c=='\n'){if(n){w[n]=0;gST->ConOut->OutputString(gST->ConOut,w);n=0;}CHAR16 nl[3]={'\r','\n',0};gST->ConOut->OutputString(gST->ConOut,nl);continue;}if(n>=382){w[n]=0;gST->ConOut->OutputString(gST->ConOut,w);n=0;}w[n++]=(u8)c;}if(n){w[n]=0;gST->ConOut->OutputString(gST->ConOut,w);}}
static void out(const char*s){raw_ascii(s);}
static void line(const char*s){out(s);out("\n");}
static void out_i(i64 v){char b[48];d3_i64str(v,b);out(b);}
static void out_hex(d_u64 v){char b[24];g3_hex64(v,b);out(b);}

/* filesystem on the boot volume */
static EFI_GUID LOADED_IMAGE_GUID={0x5B1B31A1,0x9562,0x11d2,{0x8E,0x3F,0x00,0xA0,0xC9,0x69,0x72,0x3B}};
static EFI_GUID SIMPLE_FS_GUID={0x964e5b22,0x6459,0x11d2,{0x8e,0x39,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static void to16(const char*s,CHAR16*w,int cap){int i=0;while(s[i]&&i<cap-1){w[i]=(u8)s[i];i++;}w[i]=0;}
static void fs_init(void){EFI_LOADED_IMAGE_PROTOCOL*li=0;EFI_SIMPLE_FILE_SYSTEM_PROTOCOL*fs=0;if(EFI_ERROR(gBS->HandleProtocol(gImage,&LOADED_IMAGE_GUID,(void**)&li))||!li)return;if(EFI_ERROR(gBS->HandleProtocol(li->DeviceHandle,&SIMPLE_FS_GUID,(void**)&fs))||!fs)return;fs->OpenVolume(fs,&gRoot);}
static EFI_FILE_PROTOCOL* fs_create(const char*name){if(!gRoot)return 0;CHAR16 w[96];to16(name,w,96);EFI_FILE_PROTOCOL*f=0;if(!EFI_ERROR(gRoot->Open(gRoot,&f,w,EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE,0))&&f){f->Delete(f);f=0;}if(EFI_ERROR(gRoot->Open(gRoot,&f,w,EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE,0)))return 0;return f;}
static int fs_write(const char*name,const void*data,UINTN n){EFI_FILE_PROTOCOL*f=fs_create(name);if(!f)return 0;UINTN z=n;EFI_STATUS st=f->Write(f,&z,(void*)data);f->Flush(f);f->Close(f);return !EFI_ERROR(st)&&z==n;}
static int fs_read(const char*name,void*data,UINTN cap,UINTN*got){if(!gRoot)return 0;CHAR16 w[96];to16(name,w,96);EFI_FILE_PROTOCOL*f=0;if(EFI_ERROR(gRoot->Open(gRoot,&f,w,EFI_FILE_MODE_READ,0))||!f)return 0;UINTN n=cap;EFI_STATUS st=f->Read(f,&n,data);f->Close(f);if(got)*got=n;return !EFI_ERROR(st);}

/* executable-page host for raw machine code */
typedef struct{void*p;UINTN pages;} Allocation;
static Allocation gAlloc[64];
static void* host_alloc(void*ctx,d_u64 n){(void)ctx;UINTN pages=(UINTN)((n+EFI_PAGE_SIZE-1)/EFI_PAGE_SIZE);if(!pages)pages=1;EFI_PHYSICAL_ADDRESS a=0;if(EFI_ERROR(gBS->AllocatePages(AllocateAnyPages,EfiLoaderCode,pages,&a)))return 0;for(int i=0;i<64;i++)if(!gAlloc[i].p){gAlloc[i].p=(void*)(UINTN)a;gAlloc[i].pages=pages;return gAlloc[i].p;}gBS->FreePages(a,pages);return 0;}
static void host_free(void*ctx,void*p){(void)ctx;if(!p)return;for(int i=0;i<64;i++)if(gAlloc[i].p==p){gBS->FreePages((EFI_PHYSICAL_ADDRESS)(UINTN)p,gAlloc[i].pages);gAlloc[i].p=0;gAlloc[i].pages=0;return;}}
static void host_out(void*ctx,const char*s){(void)ctx;out(s);}static void host_putc(void*ctx,char c){(void)ctx;char b[2]={c,0};out(b);}
static d_u64 EFIAPI uefi_clear(void){clear_screen();return 0;}
static d_u64 EFIAPI uefi_stall(d_u64 us){gBS->Stall((UINTN)us);return 0;}
static d_u64 EFIAPI uefi_attr(d_u64 a){attr((UINTN)a);return 0;}
static d_u64 EFIAPI uefi_print(d_u64 p){out((const char*)(UINTN)p);return 0;}
static d_u64 host_api(void*ctx,const char*dll,const char*name){(void)ctx;(void)dll;if(seq(name,"st"))return (d_u64)(UINTN)gST;if(seq(name,"bs"))return (d_u64)(UINTN)gBS;if(seq(name,"rs"))return (d_u64)(UINTN)gST->RuntimeServices;if(seq(name,"conout"))return (d_u64)(UINTN)gST->ConOut;if(seq(name,"conin"))return (d_u64)(UINTN)gST->ConIn;if(seq(name,"clear"))return (d_u64)(UINTN)&uefi_clear;if(seq(name,"stall"))return (d_u64)(UINTN)&uefi_stall;if(seq(name,"attr"))return (d_u64)(UINTN)&uefi_attr;if(seq(name,"print"))return (d_u64)(UINTN)&uefi_print;return 0;}
static d_u64 host_read_text(void*ctx,const char*path){(void)ctx;const UINTN cap=1024*1024;char*p=(char*)host_alloc(0,cap+1);if(!p)return 0;UINTN got=0;if(!fs_read(path,p,cap,&got)){host_free(0,p);return 0;}p[got]=0;return (d_u64)(UINTN)p;}
static D3Host gHost={host_out,host_putc,host_alloc,host_free,host_api,0,0,0,host_read_text};

static void frame(void){for(UINTN x=0;x<gCols;x++){pos(x,0);attr(EFI_TEXT_ATTR((x&2)?EFI_LIGHTGREEN:EFI_WHITE,EFI_BLACK));raw_ascii("=");if(gRows>1){pos(x,gRows-1);raw_ascii("=");}}for(UINTN y=1;y+1<gRows;y++){pos(0,y);raw_ascii("|");if(gCols>1){pos(gCols-1,y);raw_ascii("|");}}}
static void home(void){clear_screen();frame();attr(EFI_TEXT_ATTR(EFI_WHITE,EFI_BLACK));pos(3,2);raw_ascii("GAIA DISCOVERY SCIENCE // UEFI 2.1");attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));pos(3,3);raw_ascii("DNA:512 // IEEE:F32/F64 // TENSOR:R4 // SCIENCE:LIVE // OS:NONE");pos(3,5);raw_ascii("Gaia> ");attr(EFI_TEXT_ATTR(EFI_WHITE,EFI_BLACK));gST->ConOut->EnableCursor(gST->ConOut,1);}
static void output_begin(void){pos(3,8);attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));}
static void wait_key(void){line("\n[press any key]");EFI_EVENT e=gST->ConIn->WaitForKey;UINTN ix=0;gBS->WaitForEvent(1,&e,&ix);EFI_INPUT_KEY k;gST->ConIn->ReadKeyStroke(gST->ConIn,&k);}
static int read_line_at(char*b,int cap,UINTN x,UINTN y){int n=0;b[0]=0;pos(x,y);for(;;){EFI_EVENT e=gST->ConIn->WaitForKey;UINTN ix=0;gBS->WaitForEvent(1,&e,&ix);EFI_INPUT_KEY k;if(EFI_ERROR(gST->ConIn->ReadKeyStroke(gST->ConIn,&k)))continue;if(k.ScanCode==SCAN_ESC)return -1;u16 c=k.UnicodeChar;if(c=='\r'){b[n]=0;return n;}if(c==8){if(n>0){n--;b[n]=0;UINTN cx=x+(UINTN)n;pos(cx,y);raw_ascii(" ");pos(cx,y);}continue;}if(c>=32&&c<127&&n<cap-1){b[n++]=(char)c;b[n]=0;char q[2]={(char)c,0};raw_ascii(q);}}}

static void show_source(void){if(!gSourceN){line("[source empty] // example loads a real program");return;}int ln=1,p=0;while(p<gSourceN){if(gLines){out_i(ln++);out(" | ");}char b[512];int n=0;while(p<gSourceN&&gSource[p]!='\n'&&n<510)b[n++]=gSource[p++];if(p<gSourceN&&gSource[p]=='\n')p++;b[n]=0;line(b);}}
static void append_line(const char*s){int n=slen(s);if(gSourceN+n+1>=(int)sizeof(gSource))return;for(int i=0;i<n;i++)gSource[gSourceN++]=s[i];gSource[gSourceN++]='\n';gSource[gSourceN]=0;}
static void undo_line(void){if(gSourceN<=0)return;if(gSourceN&&gSource[gSourceN-1]=='\n')gSourceN--;while(gSourceN>0&&gSource[gSourceN-1]!='\n')gSourceN--;gSource[gSourceN]=0;}
static int compile_source(const char*src){if(!d3_compile(&gProg,src)){out("COMPILE ERROR // line ");out_i(gProg.error_line);out(" // ");line(gProg.error);return 0;}out("COMPILE OK // ");out_i(gProg.ncode);out(" ops // ");out_i(gProg.nvars);line(" vars");return 1;}
static void run_source(const char*src){if(!compile_source(src))return;D3VM vm;if(!d3_run(&gProg,&gHost,&vm,100000000)){out("VM FAULT // ");line(vm.error_text);}else line("RUN COMPLETE");}
static void editor(void){clear_screen();attr(EFI_TEXT_ATTR(EFI_WHITE,EFI_BLACK));line("GAIA EDIT // .done .run .show .undo .new");attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));if(gSourceN)show_source();for(;;){char b[512];out(gLines?"> ":"> ");UINTN x=gST->ConOut->Mode?(UINTN)gST->ConOut->Mode->CursorColumn:2,y=gST->ConOut->Mode?(UINTN)gST->ConOut->Mode->CursorRow:2;int n=read_line_at(b,512,x,y);line("");if(n<0||seq(b,".done"))break;if(seq(b,".run")){run_source(gSource);continue;}if(seq(b,".show")){show_source();continue;}if(seq(b,".undo")){undo_line();line("UNDO");continue;}if(seq(b,".new")){gSourceN=0;gSource[0]=0;line("NEW");continue;}append_line(b);}home();}

static const char *EXAMPLE=
"// GAIA 2: heredity + uncertainty + evidence + search + metal.\n"
"dna ancestor = family(137, 53);\n"
"population cells = population(ancestor, 1000);\n"
"unknown hidden;\n"
"println(\"hidden state: \", hidden);\n"
"interval observed = interval(28000, 36000);\n"
"population adapted = evolve_target(cells, 448, 32000, 250, 64, 5300);\n"
"u32 phenotype = gene(popdna(adapted), 448);\n"
"println(\"phenotype: \", phenotype);\n"
"println(\"inside observation band: \", icontains(observed, phenotype));\n"
"println(\"evidence q16: \", support(imid(observed), phenotype, iwidth(observed)));\n"
"println(\"receipt: \", receipt(ancestor, popdna(adapted), phenotype, 53));\n"
"println(\"native x64 says: \", asm { B8 2A 00 00 00 C3 });\n"
"halt;\n";
static void load_example(void){int n=slen(EXAMPLE);if(n>=(int)sizeof(gSource))n=(int)sizeof(gSource)-1;for(int i=0;i<n;i++)gSource[i]=EXAMPLE[i];gSource[n]=0;gSourceN=n;line("EXAMPLE LOADED // show | run | edit");}

static void inspect_dna(d_u32 fam){d_u32 d=g3_atlas_dna(fam,53);out("FAMILY ");out_i(fam&511);out(" // DNA ");out_hex(d);out(" // ROOT16 ");out_i(g3_poly16(d,32,16));out(" // MEMORY16 ");out_i(g3_poly16(d,496,16));line("");}
static void lens_cmd(char*s){d_u32 fam=(d_u32)parse_u64(s),d=g3_atlas_dna(fam,53);while(*s&&*s!=' ')s++;while(*s==' ')s++;d_u32 st=*s?(d_u32)parse_u64(s):0;while(*s&&*s!=' ')s++;while(*s==' ')s++;d_u32 n=*s?(d_u32)parse_u64(s):16;if(n>64)n=64;for(d_u32 i=0;i<n&&st+i<512;i++){d_u32 l=st+i;out("L");out_i(l);out(" D");out_i(l>>4);out(" O");out_i(l&15);out(" Q16 ");out_i(g3_gene16(d,l));line("");}}

static void save_source(void){line(fs_write("gaia.gaia",gSource,(UINTN)gSourceN)?"SAVE OK // gaia.gaia":"SAVE FAILED");}
static void load_source(void){UINTN n=0;if(fs_read("gaia.gaia",gSource,sizeof(gSource)-1,&n)){gSourceN=(int)n;gSource[gSourceN]=0;line("LOAD OK // gaia.gaia");}else line("LOAD FAILED // gaia.gaia not found");}
static void build_gvm(void){if(!compile_source(gSource))return;EFI_FILE_PROTOCOL*f=fs_create("gaia.gvm");if(!f){line("BUILD FAILED // filesystem");return;}D3Head h={{'G','A','I','A'},2,(d_u32)gProg.ncode,(d_u32)gProg.nvars,0};UINTN n=sizeof(h);f->Write(f,&n,&h);n=(UINTN)(gProg.ncode*(int)sizeof(D3Ins));f->Write(f,&n,gProg.code);f->Flush(f);f->Close(f);line("BUILD OK // gaia.gvm");}
static void metal_emit(int coff){char er[160];int n=0;if(!dm_extract(gSource,gMetal,DM_MAX,&n,er,160)){line(er);return;}const void*p=gMetal;int bytes=n;const char*fn="gaia.bin";if(coff){bytes=dm_coff(gMetal,n,gCoff,DM_MAX+128);p=gCoff;fn="gaia.obj";if(!bytes){line("COFF ERROR");return;}}if(fs_write(fn,p,(UINTN)bytes)){out(coff?"OBJ OK // ":"METAL OK // ");out(fn);out(" // ");out_i(bytes);line(" bytes");}else line("WRITE FAILED");}

static void help(void){line("GAIA DISCOVERY SYSTEMS COMMANDS");line("example  edit  show  run  do CODE  save  load  build  metal  obj");line("dna N  lens FAMILY START COUNT  lang  discovery  science  uefi  clear  exit");}
static void manual(const char*t){if(!t||!*t){line("GAIA 2 = hereditary systems language + discovery/science machinery.");line("man lang | man dna | man discovery | man science | man memory | man asm | man uefi");return;}if(seq(t,"lang")){line("TYPES // machine + dna + unknown + interval + vector/matrix + population + model/evidence/world");line("CONTROL // labels, goto, if EXPR goto LABEL, call/return, halt");line("OPS // + - * / % << >> & | ^ ~ ! && || == != < <= > >=");}else if(seq(t,"dna")){line("DNA // family(f[,seed]) gene(d,locus) poly(d,start,count) mutate(d,rate10000[,seed]) breed(a,b,rate10000[,seed]) hash(\"text\")");line("gene/poly return Q16 integers 0..65535. rate10000 means 600 = 6.00%.");}else if(seq(t,"discovery")){line("DISCOVERY // unknown/isunknown/coalesce interval surprise/support/falsify/receipt");line("SCIENCE // vector/vget/vset/vmean matrix/mget/mset populations + bounded evolutionary search");line("SEARCH // evolve_target evolve_max evolve_min seekpoly; ENSEMBLE // mean4 worst4 spread4");}else if(seq(t,"science")){line("IEEE // f32/f64 literals + explicit floating operators + conversion + printing");line("TENSOR // tensor1..4 tget/tset/tfill/tsum/tmean/taxpy; AUTODIFF // dual/dadd/dmul/dgrad");line("SOLVERS // ode_euler ode_rk4_linear pde_heat1d sde_em; BAYES // posterior_sample bayes_mean mh_step");line("DATA // csv/tsv/loadcsv/loadtsv; GPU // gpu_axpy with OpenCL host or identical CPU fallback");}else if(seq(t,"memory")){line("RAW MEMORY // alloc/free + peek8/16/32/64 + poke8/16/32/64");line("Pointers are 64-bit machine values. UEFI allocations use EfiLoaderCode pages.");}else if(seq(t,"asm")){line("INLINE X64 // asm { B8 2A 00 00 00 C3 } executes bytes and returns RAX.");line("metal/obj extract asm plus byte/word/dword/qword/align/pad into gaia.bin / gaia.obj.");}else if(seq(t,"uefi")){line("UEFI API // api(\"uefi\",\"st\"|\"bs\"|\"rs\"|\"conout\"|\"conin\")");line("Functions clear/stall/attr/print can be resolved with api() and called with native().");}else line("NO MAN ENTRY");}

static void command(char*c){output_begin();if(!*c)return;if(seq(c,"list")||seq(c,"help")){help();return;}if(seq(c,"man")){manual(0);return;}if(prefix(c,"man ")){manual(c+4);return;}if(seq(c,"example")){load_example();return;}if(seq(c,"edit")){editor();return;}if(seq(c,"show")){show_source();return;}if(seq(c,"run")){run_source(gSource);return;}if(prefix(c,"do ")){run_source(c+3);return;}if(seq(c,"save")){save_source();return;}if(seq(c,"load")){load_source();return;}if(seq(c,"build")){build_gvm();return;}if(seq(c,"metal")){metal_emit(0);return;}if(seq(c,"obj")){metal_emit(1);return;}if(prefix(c,"dna ")){inspect_dna((d_u32)parse_u64(c+4));return;}if(prefix(c,"lens ")){lens_cmd(c+5);return;}if(seq(c,"lang")){manual("lang");return;}if(seq(c,"discovery")){manual("discovery");return;}if(seq(c,"science")){manual("science");return;}if(seq(c,"uefi")){manual("uefi");return;}if(seq(c,"new")){gSourceN=0;gSource[0]=0;line("NEW // source empty");return;}if(seq(c,"lines")){gLines=!gLines;line(gLines?"LINES ON":"LINES OFF");return;}if(seq(c,"clear")||seq(c,"home")){home();return;}if(seq(c,"exit")){gExit=1;return;}line("UNKNOWN GAIA // list | man | example");}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandle,EFI_SYSTEM_TABLE *SystemTable){gImage=ImageHandle;gST=SystemTable;gBS=SystemTable->BootServices;gSource[0]=0;gSourceN=0;fs_init();if(gST->ConOut->Mode&&gST->ConOut->QueryMode){UINTN c=0,r=0;if(!EFI_ERROR(gST->ConOut->QueryMode(gST->ConOut,(UINTN)gST->ConOut->Mode->Mode,&c,&r))&&c>=40&&r>=15){gCols=c;gRows=r;}}home();while(!gExit){char cmd[512];int n=read_line_at(cmd,512,9,5);if(n<0){home();continue;}command(cmd);if(gExit)break;if(!seq(cmd,"clear")&&!seq(cmd,"home")&&!seq(cmd,"edit")){wait_key();home();}}clear_screen();attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));line("GAIA returning to firmware.");return EFI_SUCCESS;}
