# GAIA // PLEOMORPHIC DNA PROGRAMMING

```text
                 source
                   │
                   ▼
                GAIA>
                   │
          ┌────────┴────────┐
          │                 │
      SCRIPT VM         DNA VM
          │                 │
   control / loops      512 loci
                            │
                32 domains × 16 operators
                            │
              one locus → many organs
                            │
      ┌─────────┬───────────┼──────────┬─────────┐
      ▼         ▼           ▼          ▼         ▼
   COMPUTE   CHEMISTRY   WEATHER   ARCHITECTURE  MUSIC
                                       │
                                       ▼
                                  EXPRESSION
```

**GAIA is a language where executable programs can be genomes.**

It takes the genomic machinery developed for Captain Dot Gardenworld and removes Captain Dot, movement, goals, harvesting, terraforming, and the game. What remains becomes a programming model.

## THE CROWN

- **512 lineage families**
- **512 deterministic loci per genome**
- **32 pleomorphic domains**
- **16 operators per domain**
- recombination
- mutation
- deterministic expression
- phenotype generation
- chemistry channels
- agent affinities
- architecture channels
- weather channels
- generative music channels
- procedural visual expression
- context-sensitive execution
- a tiny conventional control language around the genome VM

A 32-bit DNA value expands deterministically into a 512-locus executable field.

Each locus has:

```text
ADDRESS
DOMAIN
OPERATOR
EXPRESSION VALUE
PLEOMORPHIC ECHO
```

The operator is selected by the locus address. The operand is the deterministic gene value. The same locus also whispers into secondary organs, so one genome can express itself across several systems at once.

## HELLO GENOME

```gaia
seed 53;

dna dreamwood = family 137;

emit dreamwood;
express dreamwood 12;
lens dreamwood 448 16;

halt;
```

Run in a browser:

```text
open GAIA.html
F5
```

Run with Node:

```bash
node gaia.js examples/hello_genome.gaia
```

## BREED PROGRAMS

```gaia
dna rain = family 11;
dna memory = family 31;

dna child = breed rain memory 0.06;

context rain = 0.86;
context memory = 0.91;

express child 24;
emit child;
```

The child is another executable genome.

## MUTATE PROGRAMS

```gaia
dna ancestor = word "the old machine dreams of forests";
let i = 0;

loop:
dna child = mutate ancestor 0.08;
express child 4;
dna ancestor = child;
i = i + 1;
if i < 12 goto loop;

emit child;
halt;
```

## 32 DOMAINS

```text
SOIL          WATER         ROOT          STEM
LEAF          BLOOM         SEED          FRUIT
LIGHT         HEAT          COLD          RAIN
DROUGHT       FROST         WIND          MINERAL
MICROBE       SYMBIOSIS     ALLELOPATHY   POLLINATOR
GRAZER        WISP          ARCHITECTURE  CISTERN
NURSERY       LANTERN       ARCH          RHYTHM
PITCH         TIMBRE        HARMONY       MEMORY
```

## 16 OPERATORS

```text
AMPLIFY    DAMP       STORE      RELEASE
SEEK       AVOID      LINK       SPLIT
CYCLE      PULSE      SLEEP      WAKE
MUTATE     RESONATE   MIRROR     TRANSMUTE
```

`32 × 16 = 512` addressable instructions/loci.

## CONTEXT IS ENVIRONMENT

DNA does not have to change when conditions change.

```gaia
context water = .12;
context heat = .91;
context memory = .75;
express root 16;
```

Change the context and run the same genome again.

The source remains the same.
The DNA remains the same.
The expression changes.

## LANGUAGE SURFACE

```text
seed N
context NAME = EXPR
let NAME = EXPR
var NAME = EXPR

dna NAME = family N
dna NAME = 0xDEADBEEF
dna NAME = word "text"
dna NAME = breed A B [RATE]
dna NAME = mutate A [RATE]

breed A B -> CHILD
mutate A RATE -> CHILD

express DNA [STEPS]
music DNA [BEATS]
lens DNA [START] [COUNT]
atlas [PAGE]
emit DNA
print EXPR

label:
if EXPR goto label
goto label
halt
```

Expressions include conventional arithmetic, comparisons, bitwise logic and:

```text
gene(dna,locus)
poly(dna,start,count)
family(dna)
mut(dna,rate)
breed(a,b,rate)
hash("text")
rand()
min max abs sin cos sqrt clamp
```

## BROWSER ENVIRONMENT

`GAIA.html` is a zero-build single-file environment.

```text
SOURCE                    EXPRESSION FIELD
  │                            │
  │                         1 FIELD
  │                         2 LENS
  │                         3 ATLAS
  │                         M MUSIC
  │                         C CALM
  │
  └────────────────────── Gaia>
```

Useful prompt commands:

```text
list
man
man dna
man express
man pleomorphism
run
example
field
lens
atlas
music
calm
wake
save
load
export
```

## WHY DNA?

Ordinary source code tends to say:

```text
DO THIS
THEN THIS
THEN THIS
```

Gaia can also say:

```text
THIS IS THE GENOME.
THIS IS THE ENVIRONMENT.
EXPRESS.
```

The program is not only a sequence.
It can be a **potential field**.

## PLEOMORPHISM

The central rule:

> **one gene should be allowed to matter in more than one place.**

A locus can affect its primary domain and echo into another organ. The complete genome is then read into compute state, chemistry, weather, architecture, agent affinities, image and music.

This is deliberately unlike a one-feature-per-gene configuration file.

## FILES

```text
GAIA.html                 zero-build browser environment
gaia_core.js              language + genome VM core
gaia.js                   Node CLI / REPL
GAIA_SPEC.md              compact language specification
examples/
  hello_genome.gaia
  breed_programs.gaia
  evolution_loop.gaia
```

## THE SHORT VERSION

```text
Dream asks:
    how little language reaches the whole machine?

Gaia asks:
    how little genome expresses a whole program ecology?

Gaia> _
```
