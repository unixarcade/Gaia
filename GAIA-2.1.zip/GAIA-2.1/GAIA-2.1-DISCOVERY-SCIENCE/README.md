# GAIA 2.1 // DISCOVERY SCIENCE SYSTEMS

**Programs are genomes. Execution is expression. Models are organisms. Solutions can be species. Unknown is a value. Failure is evidence. Scientific state can touch the metal.**

GAIA 2.1 keeps the original 512-locus hereditary language, the Dream-derived systems/UEFI path, and GAIA 2.0's discovery semantics, then implements the missing compact scientific crown: IEEE floating point, tensors, autodiff, Bayesian sampling, ODE/PDE/SDE solvers, GPU acceleration hooks, and scientific dataset adapters.

The design rule remains: **never add a scientific keyword until its semantics execute and pass tests.**

## What is implemented now

### Hereditary systems + discovery core

The GAIA 2.0 machinery remains intact:

```text
dna / family / gene / poly / mutate / breed
UNKNOWN + interval uncertainty
surprise / support / falsify / receipt
vectors / matrices
populations + bounded hereditary search
ensemble robustness
raw memory / native calls / inline x86-64 / COFF / UEFI
```

### IEEE-754 floating point

Decimal and exponent literals compile directly to IEEE binary64 bits:

```gaia
f64 x = 1.5;
f64 y = 2.25e1;
f64 z = fdiv(fadd(x,y),3.0);
printf64(z);
```

`f32` and `f64` are accepted declaration spellings. The VM still uses one 64-bit machine cell per value; binary64 occupies the cell bit-for-bit, while binary32 occupies its low 32 bits. Floating arithmetic is explicit so integer/raw-machine arithmetic remains unambiguous:

```text
f32(x)                 f64 -> f32
f32tof64(x)
itof64(x)  f64toi(x)
itof32(x)  f32toi(x)

fadd fsub fmul fdiv
fneg fabs fsqrt fmin fmax
feq flt fle fgt fge

f32add f32sub f32mul f32div
printf64 printf32
```

The freestanding EFI target executes these with hardware floating-point instructions and no CRT/libm dependency.

### Rank 1-4 tensors

Scientific tensors are real allocator-backed contiguous IEEE-f64 arrays:

```gaia
tensor t = tensor3(4,8,16);
tfill(t,0.0);
tset(t,17,3.5);
printf64(tget(t,17));
println(trank(t));
println(tdim(t,2));
printf64(tmean(t));
free(t);
```

Implemented operations:

```text
tensor1(n)
tensor2(a,b)
tensor3(a,b,c)
tensor4(a,b,c,d)

trank(t)  tlen(t)  tdim(t,axis)
tget(t,flat_index)
tset(t,flat_index,f64)
tfill(t,f64)
tsum(t)  tmean(t)
taxpy(y,a,x)
```

Flat indexing keeps the firmware implementation tiny; shape metadata preserves the rank and dimensions.

### Forward-mode automatic differentiation

GAIA's minimal autodiff value is a packed pair of IEEE-f32 values `(value, derivative)`:

```gaia
dual x = dual(f32(3.0),f32(1.0));
dual y = dadd(dmul(dmul(x,x),x), dmul(dual(f32(2.0),f32(0.0)),x));
printf32(dval(y));   // 33
printf32(dgrad(y)); // 29
```

Implemented:

```text
dual(value,derivative)
dval dgrad
dadd dsub dmul ddiv
```

This is genuine forward-mode autodiff rather than finite differencing.

### Bayesian sampling

The first Bayesian layer deliberately uses primitives that need no large probability runtime:

```text
posterior_sample(weights,seed)
    sample a hypothesis/particle index proportional to nonnegative posterior weights

bayes_mean(values,weights)
    weighted posterior mean

mh_step(current,proposal,current_weight,proposal_weight,seed)
    one deterministic-seeded Metropolis-Hastings accept/reject step
```

Example:

```gaia
tensor w=tensor1(3);
tset(w,0,1.0); tset(w,1,2.0); tset(w,2,7.0);
println(posterior_sample(w,53));
```

Weights can be normalized or unnormalized.

### ODE solver primitives

Two deliberately small ODE tools are implemented:

```text
ode_euler(y,dydt,dt)
    generic explicit Euler step; the caller supplies the derivative

ode_rk4_linear(y,a,b,dt,steps)
    fourth-order Runge-Kutta solver for y' = a*y + b
```

The generic Euler step lets GAIA source define arbitrary dynamics itself; the RK4 linear solver supplies a compact higher-quality reference integrator.

### PDE solver

`pde_heat1d(tensor,alpha,steps)` implements the explicit finite-difference 1-D heat/diffusion equation with fixed boundary values:

```gaia
tensor u=tensor1(3);
tset(u,0,0.0); tset(u,1,1.0); tset(u,2,0.0);
pde_heat1d(u,0.25,2);
```

For robustness the solver rejects `alpha < 0`, `alpha > 0.5`, or NaN, enforcing the standard explicit-scheme stability range for this normalized stencil.

### SDE solver

`sde_em(x,drift,diffusion,dt,seed)` implements one deterministic-seeded Euler-Maruyama step:

```text
X_next = X + drift*dt + diffusion*sqrt(dt)*N(0,1)
```

The normal variate uses a compact 12-uniform central-limit approximation, avoiding a libm dependency while remaining deterministic and useful for simulation/search work.

### Scientific dataset adapters

Numeric rectangular CSV and TSV are first-class adapters:

```gaia
tensor a = csv("1.5,2.5\n3.5,4.5");
tensor b = tsv("1\t2\n3\t4");
tensor c = loadcsv("science/data/example.csv");
tensor d = loadtsv("science/data/example.tsv");
```

The in-memory adapters work anywhere GAIA has an allocator. Host-file loading is implemented in the native runner; UEFI also exposes a boot-volume text adapter (currently capped at 1 MiB per loaded dataset). The parser is intentionally a **numeric scientific CSV/TSV adapter**, not a full spreadsheet/quoted-field parser. Empty/non-numeric cells become IEEE NaN; non-rectangular data is rejected.

### GPU execution

The first GPU primitive is portable BLAS-style AXPY:

```gaia
gpu_axpy(y,0.5,x);
```

Semantics:

```text
y[i] = y[i] + a*x[i]
```

The VM exposes a host GPU interface. `tools/gaia_opencl_runner.c` implements a dynamically loaded OpenCL 1.2 GPU kernel with no compile-time OpenCL-header or linker requirement. If there is no usable fp64 OpenCL GPU, GAIA performs the identical operation on CPU.

```text
gpu_backend() -> 2 when an installed host reports a usable GPU, otherwise 1 for CPU fallback
gpu_axpy(...) -> 2 if GPU executed it, 1 if CPU fallback executed it, 0 on failure
```

This makes GPU use an acceleration property rather than a semantic fork.

## Science examples

`science/examples/` contains ten executable regressions:

```text
01 IEEE f32/f64
02 forward autodiff
03 rank-4 tensors
04 posterior + Metropolis sampling
05 ODE Euler + RK4
06 PDE heat diffusion
07 SDE Euler-Maruyama
08 CSV/TSV memory + file adapters
09 OpenCL/CPU-identical GPU AXPY
10 hereditary-discovery-science bridge
```

The older `discovery/examples/` suite remains and still passes.

## Build and test

Requirements for the full default build:

- clang
- lld-link
- Python 3
- Node.js (original hosted-GAIA regression only)
- `libdl` on Linux for compiling the optional dynamic OpenCL runner

No OpenCL development headers are required. A physical GPU is not required because the GPU path has a tested CPU fallback.

```bash
./build.sh
```

Or separately:

```bash
make test
make iso
```

The test crown runs:

```text
original hosted GAIA regressions
GAIA Systems host regression
10 GAIA 2.0 discovery programs
10 GAIA 2.1 science programs
AddressSanitizer + UndefinedBehaviorSanitizer science/discovery runs
OpenCL adapter compile + numerical-path test
freestanding x86-64 EFI build
FAT12 ESP + El Torito UEFI ISO build
```

## UEFI outputs

```text
BOOTX64.EFI
GAIA-2.1-SCIENCE-UEFI.iso
gaia-science-esp.img
```

Boot path:

```text
POWER -> UEFI -> EFI/BOOT/BOOTX64.EFI -> Gaia>
```

At firmware level:

```text
Gaia> example
Gaia> run
Gaia> science
Gaia> discovery
Gaia> edit
```

The compiler, IEEE arithmetic, tensors, autodiff primitives, Bayesian primitives, solvers, dataset parser, CPU GPU-fallback kernel, hereditary machinery, raw memory and x64 machinery are all compiled into the freestanding EFI application.

## Repository map

```text
hosted/                  original rich pleomorphic GAIA engine
uefi/                    freestanding GAIA compiler/VM + UEFI shell
discovery/               GAIA 2.0 discovery semantics and tests
science/                 GAIA 2.1 scientific crown, data and tests
tools/                   host runners, OpenCL adapter, tests, ISO builder
lineage/                 Dream Land lineage notes
BOOTX64.EFI              freestanding firmware application
GAIA-2.1-SCIENCE-UEFI.iso
                          bootable UEFI ISO
gaia-science-esp.img     FAT EFI System Partition image
```

## What is still deliberately outside this small crown

GAIA 2.1 does **not** pretend the following are already complete:

- arbitrary user-defined callback functions passed directly into RK4/PDE/SDE solvers
- reverse-mode autodiff / full computational graphs
- sparse tensors/matrices
- complex arithmetic
- NUTS/HMC, variational inference, or a full probabilistic-programming runtime
- general multidimensional PDE discretizers
- CUDA/Metal/Vulkan compute backends (the host API can accept them later; OpenCL is the implemented reference adapter)
- NetCDF/HDF5/Parquet scientific schemas
- physical units/dimensional-analysis enforcement
- distributed tensor/population execution

Those are now extensions of a working numerical substrate rather than missing foundations.

## Biomedical boundary

The cancer/HIV/cold/AMR programs in `discovery/examples/` remain synthetic **language and algorithm benchmarks**. GAIA 2.1 now has much better machinery for validated scientific models and real datasets, but it does not turn synthetic examples into biological evidence. Real biomedical conclusions require validated models, measured data, controls, and experimental/clinical verification.
