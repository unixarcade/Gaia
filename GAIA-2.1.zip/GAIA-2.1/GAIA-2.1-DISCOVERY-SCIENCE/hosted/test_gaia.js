'use strict';
const G=require('./gaia_core.js');
function ok(x,m){if(!x)throw Error('FAIL '+m);console.log('PASS // '+m)}
ok(G.GDOM.length===32,'32 domains');
ok(G.GOP.length===16,'16 operators');
let d=G.atlasDNA(137,53);ok(G.family(d)===137,'family encoding');
let vals=Array.from({length:512},(_,i)=>G.gene(d,i));ok(vals.every(v=>v>=0&&v<1),'512 deterministic loci');
let a=G.atlasDNA(11,53),b=G.atlasDNA(31,53),c=G.breed(a,b,5300,.06);ok(c!==a&&c!==b,'breed executable genomes');
let m=G.mutate(c,.08,53);ok(m!==c,'mutation');
let ex=G.express(m,12,{water:.8,memory:.9});ok(ex.regs.length===32&&ex.locusEnergy.length===512,'pleomorphic expression');
ok(ex.music&&ex.architecture&&ex.weather&&ex.chemistry&&ex.affinities,'multi-organ phenotype');
let env=G.run('seed 53; dna x = family 137; express x 8; print family(x); halt;');ok(env.last&&env.last.family===137,'source compiler/interpreter');
console.log('GAIA TEST COMPLETE // '+env.last.hex+' // '+env.last.checksum);
