# GAIA 2.1 Scientific Crown — Implemented Semantics

## Representation

The VM remains a 64-bit-cell machine. IEEE binary64 occupies one cell bit-for-bit. IEEE binary32 occupies the low 32 bits. Tensor payloads are contiguous binary64 cells. Forward-mode dual values pack two binary32 values into one 64-bit cell.

`f32`, `f64`, `dual`, and `tensor` are declaration spellings in the compact language. Floating operations are explicit (`fadd`, `fmul`, etc.) so raw integer/pointer arithmetic retains its original semantics.

## Decimal literals

The lexer now recognizes decimal points and scientific notation and converts them to IEEE binary64 without `strtod` or a C runtime. Hexadecimal literals retain the existing integer meaning.

## Tensor semantics

Tensors have rank 1-4, a fixed shape, a contiguous f64 payload, and flat element indexing. A tensor allocation is capped at 16,777,216 cells to bound firmware memory requests and multiplication overflow.

## Autodiff

`dual(v,d)` represents value `v` and forward derivative `d`. Addition/subtraction apply componentwise. Product and quotient rules are implemented directly. This is exact forward-mode differentiation up to IEEE-f32 rounding.

## Bayesian primitives

`posterior_sample` performs weighted categorical sampling from nonnegative finite tensor weights. `bayes_mean` returns the weighted mean. `mh_step` implements one Metropolis-Hastings accept/reject decision using unnormalized positive weights. All randomness derives deterministically from the supplied seed.

## ODE

`ode_euler` is a generic explicit step where source code supplies the derivative. `ode_rk4_linear` is a fourth-order reference integrator for `y' = a*y+b` and caps steps at one million per invocation.

## PDE

`pde_heat1d` implements the normalized explicit stencil:

`u[i] <- u[i] + alpha*(u[i-1] - 2*u[i] + u[i+1])`

Boundary values are fixed. NaN alpha or alpha outside `[0,0.5]` is rejected. Steps are capped at 100,000.

## SDE

`sde_em` performs Euler-Maruyama. Its standard-normal term is approximated by the sum of 12 deterministic uniforms minus 6. This avoids `log`, `cos`, and a libm dependency while retaining a compact approximately Gaussian driver.

## Dataset adapters

`csv` and `tsv` parse numeric rectangular strings directly to rank-2 f64 tensors. `loadcsv`/`loadtsv` request text through the host adapter then invoke the same parser. Non-rectangular data is rejected. Empty or nonnumeric cells become IEEE NaN.

The native runner reads files up to 16 MiB. The UEFI boot-volume adapter reads up to 1 MiB per file.

## GPU

The VM defines an optional host AXPY service. The included Linux OpenCL adapter dynamically loads OpenCL 1.2, discovers a GPU, builds a tiny fp64 kernel, and executes AXPY. Failure or absence falls back to the exact CPU AXPY semantics.

No OpenCL headers are required at build time. A host may later implement the same callback using CUDA, Metal, Vulkan compute, FPGA DMA, or another accelerator without changing GAIA source semantics.

## Freestanding guarantee

The x86-64 EFI target links with `/nodefaultlib`. IEEE and solver code use arithmetic emitted directly by clang plus GAIA's own compact square-root/noise helpers. The COFF `_fltused` marker is defined locally; it is not a runtime library dependency.
