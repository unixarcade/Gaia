# GAIA 2.0 Discovery Semantics

## Runtime representation

The firmware VM remains intentionally tiny: values are 64-bit cells. DNA values are 32-bit hereditary machine values carried losslessly in a cell. Populations pack a 32-bit DNA value and a 32-bit population size. Intervals pack signed 32-bit low/high bounds. Vectors and matrices are allocator-backed 64-bit integer arrays with compact headers.

## UNKNOWN

`unknown x;` initializes `x` to the dedicated 64-bit UNKNOWN sentinel. `println` renders it as `UNKNOWN`. Addition, subtraction, multiplication and division propagate unknownness. Relational comparisons involving UNKNOWN return false instead of fabricating an ordering. `coalesce` is the explicit escape hatch.

This is designed to distinguish *not observed / not known* from zero or false.

## Evidence semantics

`surprise(a,b)` is absolute scalar residual.

`support(pred,obs,tol)` returns Q16 support from 65535 at zero residual down to 0 at or above the tolerance. It is a generic numerical evidence score, not a statistical p-value or clinical confidence.

`falsify(pred,obs,tol)` is true when residual exceeds tolerance.

`receipt(a,b,c,d)` hashes four scalar experiment components into a deterministic 32-bit receipt for reproducibility checks.

## Search semantics

The evolutionary search operations are deterministic bounded hill searches over GAIA DNA mutations. They do not claim biological evolution fidelity. Their purpose is to make hereditary search a language primitive.

`evolve_target` mutates the DNA inside a population and retains candidates whose selected locus is closer to a target.

`evolve_max/min` retain candidates with more extreme locus values.

`seekpoly` searches for a genome whose polygenic mean approaches a target.

Trial counts are capped at 4096 per primitive to keep execution finite in firmware.

## Ensemble semantics

`worst4` returns the minimum of four scalar scores, making robust/worst-case objectives concise. `spread4` measures range. These are intentionally domain-neutral.

## Scientific containers

Vectors and matrices are real allocations made through the host allocator. Under UEFI those allocations come from firmware pages; under the host runner they come from the C allocator. They are not merely syntax tags.

## System boundary

GAIA 2 keeps the original raw-memory and machine-code escape hatches. Discovery calculations can therefore feed configuration words, tables, firmware state or generated machine bytes when that is appropriate.

## Biomedical boundary

The included biomedical files are synthetic executable benchmarks for language semantics. No numerical value in them is a dosage, prognosis, patient measurement or validated disease parameter. Replacing those toy worlds with validated models/data is separate scientific work.

## GAIA 2.1 science bridge

The former 2.0 roadmap items for IEEE f32/f64, tensors, forward autodiff, compact Bayesian sampling, ODE/PDE/SDE solving, OpenCL GPU acceleration, and numeric CSV/TSV adapters are implemented in `science/` and the shared freestanding VM. See `science/GAIA21_SPEC.md`.

Still-future layers include sparse tensors, complex numbers, reverse-mode autodiff, general callback-based solver APIs, full probabilistic programming, multidimensional PDE frameworks, additional GPU backends, richer scientific file formats, physical units, and distributed execution.
