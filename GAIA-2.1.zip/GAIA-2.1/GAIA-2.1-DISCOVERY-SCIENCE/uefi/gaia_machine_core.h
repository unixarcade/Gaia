#ifndef GAIA_MACHINE_CORE_H
#define GAIA_MACHINE_CORE_H

/* GAIA Systems machine core. Descended from Dream C 3.2: tiny compiler + stack VM, no CRT.
   GAIA adds DNA as a first-class 32-bit machine value and deterministic genome intrinsics. */
typedef unsigned char d_u8;
typedef unsigned short d_u16;
typedef unsigned int d_u32;
typedef signed int d_i32;
typedef unsigned long long d_u64;
typedef long long d_i64;

#define D3_MAX_CODE 8192
#define D3_MAX_VARS 256
#define D3_MAX_LABELS 512
#define D3_MAX_MACROS 64
#define D3_MAX_STACK 2048
#define D3_MAX_CALL 256
#define D3_MAX_USTACK 1024
#define D3_TEXT 112
#define D3_RAW 96
#define D3_MS __attribute__((ms_abi))

enum {
 D3_NOP=0,
 D3_PUSHI, D3_PUSHS, D3_LOAD, D3_STORE, D3_DUP, D3_DROP,
 D3_ADD, D3_SUB, D3_MUL, D3_DIV, D3_MOD, D3_SHL, D3_SHR,
 D3_BAND, D3_BOR, D3_BXOR, D3_LAND, D3_LOR,
 D3_EQ, D3_NE, D3_LT, D3_LE, D3_GT, D3_GE,
 D3_NEG, D3_LNOT, D3_BNOT, D3_WEAVE, D3_FLOW, D3_EMIT,
 D3_PRINTI, D3_PRINTS, D3_PUTC,
 D3_JMP, D3_JZ, D3_JNZ, D3_CALL, D3_RET, D3_HALT,
 D3_PEEK8, D3_PEEK16, D3_PEEK32, D3_PEEK64,
 D3_POKE8, D3_POKE16, D3_POKE32, D3_POKE64,
 D3_ALLOC, D3_FREE, D3_API, D3_NATIVE,
 D3_UPUSH, D3_UPOP, D3_ASM,
 G3_FAMILY, G3_GENE, G3_POLY, G3_MUTATE, G3_BREED, G3_HASH, G3_PRINTHEX,
 /* GAIA 2 discovery/science opcodes */
 G2_UNKNOWN, G2_ISUNKNOWN, G2_KNOWN, G2_COALESCE,
 G2_ABS, G2_MIN, G2_MAX, G2_CLAMP, G2_QMUL, G2_QDIV,
 G2_INTERVAL, G2_ILO, G2_IHI, G2_IMID, G2_IWIDTH, G2_ICONTAINS,
 G2_SURPRISE, G2_SUPPORT, G2_FALSIFY, G2_RECEIPT,
 G2_VECTOR, G2_VLEN, G2_VGET, G2_VSET, G2_VSUM, G2_VMEAN, G2_VMIN, G2_VMAX, G2_VDOT,
 G2_MATRIX, G2_MROWS, G2_MCOLS, G2_MGET, G2_MSET, G2_MMEAN,
 G2_POP, G2_POPDNA, G2_POPSIZE, G2_EVOLVE_TARGET, G2_EVOLVE_MAX, G2_EVOLVE_MIN, G2_SEEKPOLY,
 G2_MEAN4, G2_WORST4, G2_SPREAD4, G2_RNG, G2_SAMPLE,
 /* GAIA 2.1 scientific crown */
 G21_F32, G21_F32TOF64, G21_ITOF64, G21_F64TOI, G21_ITOF32, G21_F32TOI,
 G21_FADD, G21_FSUB, G21_FMUL, G21_FDIV, G21_FNEG, G21_FABS, G21_FSQRT, G21_FMIN, G21_FMAX,
 G21_FEQ, G21_FLT, G21_FLE, G21_FGT, G21_FGE,
 G21_F32ADD, G21_F32SUB, G21_F32MUL, G21_F32DIV,
 G21_PRINTF64, G21_PRINTF32,
 G21_DUAL, G21_DVAL, G21_DGRAD, G21_DADD, G21_DSUB, G21_DMUL, G21_DDIV,
 G21_TENSOR1, G21_TENSOR2, G21_TENSOR3, G21_TENSOR4, G21_TRANK, G21_TLEN, G21_TDIM,
 G21_TGET, G21_TSET, G21_TFILL, G21_TSUM, G21_TMEAN, G21_TAXPY,
 G21_POST_SAMPLE, G21_BAYES_MEAN, G21_MH_STEP,
 G21_ODE_EULER, G21_ODE_RK4_LINEAR, G21_PDE_HEAT1D, G21_SDE_EM,
 G21_CSV, G21_TSV, G21_LOADCSV, G21_LOADTSV,
 G21_GPU_AXPY, G21_GPU_BACKEND
};

typedef struct {
 d_u8 op;
 d_u8 a;
 d_u16 n;
 d_i32 target;
 d_i32 aux;
 d_i64 imm;
 char text[D3_TEXT];
 d_u8 raw[D3_RAW];
} D3Ins;

typedef struct {
 char magic[4];
 d_u32 version;
 d_u32 ncode;
 d_u32 nvars;
 d_u32 reserved;
} D3Head;

typedef struct { char name[40]; d_i32 pc; } D3Label;
typedef struct { char name[40]; } D3Var;
typedef struct { char name[40]; d_u8 isstr; d_i64 num; char text[D3_TEXT]; } D3Macro;

typedef struct {
 D3Ins code[D3_MAX_CODE];
 d_i32 ncode;
 D3Label labels[D3_MAX_LABELS];
 d_i32 nlabels;
 D3Var vars[D3_MAX_VARS];
 d_i32 nvars;
 d_i32 error_line;
 char error[160];
} D3Program;

/* ---------- tiny utilities ---------- */
static int d3_len(const char*s){int n=0;while(s&&s[n])n++;return n;}
static int d3_eq(const char*a,const char*b){int i=0;for(;;i++){if(a[i]!=b[i])return 0;if(!a[i])return 1;}}
static void d3_copy(char*d,const char*s,int cap){int i=0;if(cap<1)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static int d3_alpha(char c){return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||c=='_';}
static int d3_digit(char c){return c>='0'&&c<='9';}
static int d3_alnum(char c){return d3_alpha(c)||d3_digit(c);}
static int d3_hex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return 10+c-'a';if(c>='A'&&c<='F')return 10+c-'A';return -1;}
static d_i64 d3_parse_num(const char*s){
 d_i64 sign=1,v=0;int i=0;if(s[i]=='-'){sign=-1;i++;}
 if(s[i]=='0'&&(s[i+1]=='x'||s[i+1]=='X')){i+=2;for(;;i++){int h=d3_hex(s[i]);if(h<0)break;v=(v<<4)|h;}return v*sign;}
 while(d3_digit(s[i])){v=v*10+(s[i]-'0');i++;}return v*sign;
}
static void d3_i64str(d_i64 v,char*b){char t[32];int n=0,i=0;d_u64 u;if(v<0){b[i++]='-';u=(d_u64)(-(v+1))+1;}else u=(d_u64)v;do{t[n++]=(char)('0'+u%10);u/=10;}while(u);while(n)b[i++]=t[--n];b[i]=0;}
static d_u32 g3_mix32(d_u32 x){x^=x>>16;x*=2146121005u;x^=x>>15;x*=2221713035u;return x^(x>>16);}
static d_u32 g3_hash_string(const char*s){d_u32 h=0x811c9dc5u;for(int i=0;s&&s[i];i++){h^=(d_u8)s[i];h*=16777619u;}return g3_mix32(h);}
static d_u32 g3_atlas_dna(d_u32 family,d_u32 seed){return (((family&511u)<<23)|(g3_mix32(seed^((family+1u)*0x045d9f3bu))&0x7fffffu));}
static d_u32 g3_gene16(d_u32 dna,d_u32 locus){d_u32 h=g3_mix32(dna^((800u+(locus&511u)+1u)*0x9e3779b9u));return h>>16;}
static d_u32 g3_poly16(d_u32 dna,d_u32 start,d_u32 count){if(!count)count=1;if(count>512)count=512;d_u64 sum=0;for(d_u32 i=0;i<count;i++)sum+=g3_gene16(dna,start+i);return (d_u32)(sum/count);}
static d_u32 g3_mutate(d_u32 dna,d_u32 rate10000,d_u32 seed){if(rate10000>10000u)rate10000=10000u;d_u32 scaled=(d_u32)(((d_u64)rate10000*0xffffffffULL)/10000ULL);d_u32 h=g3_mix32(dna^seed^scaled);d_u32 bits=(rate10000*16u+5000u)/10000u;if(bits<1)bits=1;for(d_u32 i=0;i<bits;i++){h=g3_mix32(h+i*0x9e3779b9u);dna^=1u<<(h&31);}if(rate10000>6500u)dna=g3_mix32(dna^h);return dna;}
static d_u32 g3_breed(d_u32 a,d_u32 b,d_u32 rate10000,d_u32 seed){d_u32 m=g3_mix32(seed^a^b),mask=g3_mix32(m^0x9e3779b9u),d=(a&mask)|(b&~mask);return g3_mutate(d,rate10000,m);}
static void g3_hex64(d_u64 v,char*b){static const char H[]="0123456789ABCDEF";b[0]='0';b[1]='x';for(int i=0;i<16;i++)b[2+i]=H[(v>>(60-4*i))&15];b[18]=0;}

/* ---------- GAIA 2 discovery/science scalar machinery ---------- */
#define G2_UNKNOWN_VALUE ((d_i64)0x8000000000000000ULL)
static int g2_is_unknown(d_i64 x){return x==G2_UNKNOWN_VALUE;}
static d_i64 g2_abs64(d_i64 x){if(g2_is_unknown(x))return G2_UNKNOWN_VALUE;if(x<0){if(x==(d_i64)0x8000000000000000ULL)return G2_UNKNOWN_VALUE;return -x;}return x;}
static d_u64 g2_uabsdiff(d_i64 a,d_i64 b){if(g2_is_unknown(a)||g2_is_unknown(b))return ~0ULL;return a>=b?(d_u64)(a-b):(d_u64)(b-a);}
static d_u64 g2_interval_pack(d_i64 lo,d_i64 hi){d_i32 a=(d_i32)lo,b=(d_i32)hi;if(a>b){d_i32 t=a;a=b;b=t;}return ((d_u64)(d_u32)a<<32)|(d_u32)b;}
static d_i32 g2_interval_lo(d_u64 x){return (d_i32)(d_u32)(x>>32);}
static d_i32 g2_interval_hi(d_u64 x){return (d_i32)(d_u32)x;}
static d_u64 g2_population_pack(d_u32 dna,d_u32 size){return ((d_u64)dna<<32)|(d_u64)size;}
static d_u32 g2_population_dna(d_u64 p){return (d_u32)(p>>32);}
static d_u32 g2_population_size(d_u64 p){return (d_u32)p;}
static d_u32 g2_search_gene(d_u32 dna,d_u32 locus,d_u32 target,d_u32 trials,d_u32 rate,d_u32 seed,int mode){
 d_u32 best=dna,bv=g3_gene16(dna,locus);d_u64 bd=mode==0?(bv>=target?(d_u64)(bv-target):(d_u64)(target-bv)):0;
 if(trials>4096u)trials=4096u; if(!trials)trials=1;
 for(d_u32 i=0;i<trials;i++){d_u32 c=g3_mutate(dna,rate,g3_mix32(seed+i*0x9e3779b9u)),v=g3_gene16(c,locus);int take=0;
  if(mode==1)take=v>bv;else if(mode==2)take=v<bv;else{d_u64 dd=v>=target?(d_u64)(v-target):(d_u64)(target-v);if(dd<bd){bd=dd;take=1;}}
  if(take){best=c;bv=v;}
 }return best;
}
static d_u32 g2_search_poly(d_u32 dna,d_u32 start,d_u32 count,d_u32 target,d_u32 trials,d_u32 rate,d_u32 seed){
 d_u32 best=dna,bv=g3_poly16(dna,start,count);d_u64 bd=bv>=target?(d_u64)(bv-target):(d_u64)(target-bv);if(trials>4096u)trials=4096u;if(!trials)trials=1;
 for(d_u32 i=0;i<trials;i++){d_u32 c=g3_mutate(dna,rate,g3_mix32(seed+i*0x85ebca6bu)),v=g3_poly16(c,start,count);d_u64 dd=v>=target?(d_u64)(v-target):(d_u64)(target-v);if(dd<bd){best=c;bv=v;bd=dd;}}return best;
}

/* ---------- GAIA 2.1 IEEE/scientific machinery ---------- */
typedef union { double f; d_u64 u; } G21F64;
typedef union { float f; d_u32 u; } G21F32;
#define G21_TENSOR_MAGIC 0x54323147u /* G21T */
typedef struct { d_u32 magic,rank; d_u64 len; d_u64 dim[4]; } G21Tensor;

static d_u64 g21_f64bits(double x){G21F64 q;q.f=x;return q.u;}
static double g21_f64(d_u64 x){G21F64 q;q.u=x;return q.f;}
static d_u32 g21_f32bits(float x){G21F32 q;q.f=x;return q.u;}
static float g21_f32(d_u32 x){G21F32 q;q.u=x;return q.f;}
static d_u64 g21_dual(d_u32 v,d_u32 d){return ((d_u64)v<<32)|d;}
static d_u32 g21_dval(d_u64 x){return (d_u32)(x>>32);}
static d_u32 g21_dgrad(d_u64 x){return (d_u32)x;}
static d_u64* g21_tdata(G21Tensor*t){return (d_u64*)(void*)(t+1);}
static int g21_tensor_ok(G21Tensor*t){return t&&t->magic==G21_TENSOR_MAGIC&&t->rank>=1&&t->rank<=4;}
static double g21_sqrt(double x){G21F64 q;q.f=x;d_u64 e=(q.u>>52)&0x7ffULL;if(e==0x7ffULL)return x;if(x<0.0)return g21_f64(0x7ff8000000000000ULL);if(x==0.0)return x;G21F64 g;g.u=(q.u>>1)+0x1ff8000000000000ULL;double y=g.f;for(int i=0;i<8;i++)y=0.5*(y+x/y);return y;}
static double g21_u01(d_u32 seed){return ((double)g3_mix32(seed)+0.5)/4294967296.0;}
static double g21_normal12(d_u32 seed){double z=-6.0;for(int i=0;i<12;i++)z+=g21_u01(g3_mix32(seed+(d_u32)i*0x9e3779b9u));return z;}
static double g21_parse_double(const char*s){
 int i=0,sign=1,exp=0,esign=1;double v=0.0,scale=1.0;
 if(s[i]=='-'){sign=-1;i++;}else if(s[i]=='+')i++;
 while(d3_digit(s[i])){v=v*10.0+(double)(s[i]-'0');i++;}
 if(s[i]=='.'){i++;while(d3_digit(s[i])){scale*=0.1;v+=(double)(s[i]-'0')*scale;i++;}}
 if(s[i]=='e'||s[i]=='E'){i++;if(s[i]=='-'){esign=-1;i++;}else if(s[i]=='+')i++;while(d3_digit(s[i])){exp=exp*10+(s[i]-'0');if(exp>308)exp=308;i++;}}
 while(exp--){if(esign>0)v*=10.0;else v*=0.1;}
 return sign<0?-v:v;
}
static void g21_f64str(d_u64 bits,char*b){
 double x=g21_f64(bits);G21F64 q;q.u=bits;d_u64 e=(q.u>>52)&0x7ffULL,m=q.u&0xfffffffffffffULL;int n=0;
 if(e==0x7ffULL){if(q.u>>63)b[n++]='-';if(m){b[n++]='n';b[n++]='a';b[n++]='n';}else{b[n++]='i';b[n++]='n';b[n++]='f';}b[n]=0;return;}
 if(q.u>>63){b[n++]='-';x=-x;}
 if(x!=0.0&&(x>=1000000000000.0||x<0.000001)){
  int ex=0;while(x>=10.0&&ex<308){x*=0.1;ex++;}while(x<1.0&&ex>-308){x*=10.0;ex--;}
  int lead=(int)x;b[n++]=(char)('0'+lead);b[n++]='.';double frac=x-(double)lead;
  for(int j=0;j<6;j++){frac*=10.0;int d=(int)frac;if(d<0)d=0;if(d>9)d=9;b[n++]=(char)('0'+d);frac-=d;}
  b[n++]='e';if(ex<0){b[n++]='-';ex=-ex;}else b[n++]='+';
  char t[8];int k=0;do{t[k++]=(char)('0'+ex%10);ex/=10;}while(ex);while(k)b[n++]=t[--k];b[n]=0;return;
 }
 d_u64 whole=(d_u64)x;char t[32];int k=0;do{t[k++]=(char)('0'+whole%10);whole/=10;}while(whole);while(k)b[n++]=t[--k];
 b[n++]='.';double frac=x-(double)(d_u64)x;
 for(int j=0;j<6;j++){frac*=10.0;int d=(int)frac;if(d<0)d=0;if(d>9)d=9;b[n++]=(char)('0'+d);frac-=d;}
 b[n]=0;
}

/* ---------- lexer ---------- */
enum {
 T_EOF=0,T_ID=256,T_NUM,T_FLOAT,T_STR,T_EQEQ,T_NE,T_LE,T_GE,T_SHL,T_SHR,T_LAND,T_LOR,
 T_WEAVE,T_MATCH,T_RESONATE,T_FLOW,T_EMIT
};
typedef struct {
 const char* src; int p,line,tok; d_i64 num; d_u64 fbits; char text[160];
} D3Lex;

static void d3_lex_skip(D3Lex*l){
 for(;;){
  char c=l->src[l->p];
  if(c==' '||c=='\t'||c=='\r'){l->p++;continue;}
  if(c=='\n'){l->p++;l->line++;continue;}
  if(c=='#'){while(l->src[l->p]&&l->src[l->p]!='\n')l->p++;continue;}
  if(c=='/'&&l->src[l->p+1]=='/'){l->p+=2;while(l->src[l->p]&&l->src[l->p]!='\n')l->p++;continue;}
  if(c=='/'&&l->src[l->p+1]=='*'){l->p+=2;while(l->src[l->p]&&!(l->src[l->p]=='*'&&l->src[l->p+1]=='/')){if(l->src[l->p++]=='\n')l->line++;}if(l->src[l->p])l->p+=2;continue;}
  break;
 }
}
static void d3_next(D3Lex*l){
 d3_lex_skip(l);l->text[0]=0;l->num=0;l->fbits=0;char c=l->src[l->p];
 if(!c){l->tok=T_EOF;return;}
 if(d3_alpha(c)){
  int n=0;while(d3_alnum(l->src[l->p])){if(n<159)l->text[n++]=l->src[l->p];l->p++;}l->text[n]=0;l->tok=T_ID;return;
 }
 if(d3_digit(c)||(c=='.'&&d3_digit(l->src[l->p+1]))){
  int n=0,isfloat=0;
  if(c=='0'&&(l->src[l->p+1]=='x'||l->src[l->p+1]=='X')){
   if(n<159)l->text[n++]=l->src[l->p++];if(n<159)l->text[n++]=l->src[l->p++];
   while(d3_hex(l->src[l->p])>=0){if(n<159)l->text[n++]=l->src[l->p];l->p++;}
  }else{
   while(d3_digit(l->src[l->p])){if(n<159)l->text[n++]=l->src[l->p];l->p++;}
   if(l->src[l->p]=='.'){isfloat=1;if(n<159)l->text[n++]=l->src[l->p++];while(d3_digit(l->src[l->p])){if(n<159)l->text[n++]=l->src[l->p];l->p++;}}
   if(l->src[l->p]=='e'||l->src[l->p]=='E'){isfloat=1;if(n<159)l->text[n++]=l->src[l->p++];if(l->src[l->p]=='+'||l->src[l->p]=='-'){if(n<159)l->text[n++]=l->src[l->p];l->p++;}while(d3_digit(l->src[l->p])){if(n<159)l->text[n++]=l->src[l->p];l->p++;}}
  }
  l->text[n]=0;
  if(isfloat){l->fbits=g21_f64bits(g21_parse_double(l->text));l->tok=T_FLOAT;}else{l->num=d3_parse_num(l->text);l->tok=T_NUM;}
  return;
 }
 if(c=='"'){
  l->p++;int n=0;while(l->src[l->p]&&l->src[l->p]!='"'){
   char q=l->src[l->p++];if(q=='\\'){
    char e=l->src[l->p++];if(e=='n')q='\n';else if(e=='r')q='\r';else if(e=='t')q='\t';else if(e=='e')q=27;else if(e=='0')q=0;else q=e;
   }
   if(n<159)l->text[n++]=q;
  }if(l->src[l->p]=='"')l->p++;l->text[n]=0;l->tok=T_STR;return;
 }
 #define D3_TWO(a,b,t) if(c==(a)&&l->src[l->p+1]==(b)){l->p+=2;l->tok=(t);return;}
 D3_TWO('=','=',T_EQEQ) D3_TWO('!','=',T_NE) D3_TWO('<','=',T_LE) D3_TWO('>','=',T_GE)
 D3_TWO('<','<',T_SHL) D3_TWO('>','>',T_SHR) D3_TWO('&','&',T_LAND) D3_TWO('|','|',T_LOR)
 D3_TWO('%','%',T_WEAVE) D3_TWO('?','=',T_MATCH)
 if(c=='<'&&l->src[l->p+1]=='-'&&l->src[l->p+2]=='>'){l->p+=3;l->tok=T_RESONATE;return;}
 if(c=='-'&&l->src[l->p+1]=='>'&&l->src[l->p+2]=='>'){l->p+=3;l->tok=T_FLOW;return;}
 if(c=='@'&&l->src[l->p+1]=='>'){l->p+=2;l->tok=T_EMIT;return;}
 #undef D3_TWO
 l->p++;l->tok=(unsigned char)c;
}

/* ---------- compiler ---------- */
typedef struct {D3Program* p;D3Lex l;D3Macro macros[D3_MAX_MACROS];int nmacros;} D3C;
static int d3_fail(D3C*c,const char*m){if(!c->p->error[0]){c->p->error_line=c->l.line;d3_copy(c->p->error,m,160);}return 0;}
static D3Ins* d3_emit(D3C*c,int op){if(c->p->ncode>=D3_MAX_CODE){d3_fail(c,"program too large");return 0;}D3Ins*i=&c->p->code[c->p->ncode++];d_u8*z=(d_u8*)i;for(int k=0;k<(int)sizeof(*i);k++)z[k]=0;i->op=(d_u8)op;return i;}
static int d3_var(D3C*c,const char*n){for(int i=0;i<c->p->nvars;i++)if(d3_eq(c->p->vars[i].name,n))return i;if(c->p->nvars>=D3_MAX_VARS){d3_fail(c,"too many variables");return -1;}int id=c->p->nvars++;d3_copy(c->p->vars[id].name,n,40);return id;}
static int d3_label(D3C*c,const char*n){for(int i=0;i<c->p->nlabels;i++)if(d3_eq(c->p->labels[i].name,n))return i;if(c->p->nlabels>=D3_MAX_LABELS){d3_fail(c,"too many labels");return -1;}int id=c->p->nlabels++;d3_copy(c->p->labels[id].name,n,40);c->p->labels[id].pc=-1;return id;}
static int d3_accept(D3C*c,int t){if(c->l.tok==t){d3_next(&c->l);return 1;}return 0;}
static int d3_expect(D3C*c,int t,const char*m){if(c->l.tok!=t)return d3_fail(c,m);d3_next(&c->l);return 1;}
static int d3_isid(D3C*c,const char*n){return c->l.tok==T_ID&&d3_eq(c->l.text,n);}
static int d3_macro_find(D3C*c,const char*n){for(int i=0;i<c->nmacros;i++)if(d3_eq(c->macros[i].name,n))return i;return -1;}
static int d3_macro_new(D3C*c,const char*n){int i=d3_macro_find(c,n);if(i>=0)return i;if(c->nmacros>=D3_MAX_MACROS){d3_fail(c,"too many macros");return -1;}i=c->nmacros++;d3_copy(c->macros[i].name,n,40);c->macros[i].isstr=0;c->macros[i].num=0;c->macros[i].text[0]=0;return i;}

static int d3_expr(D3C*c);

static int d3_builtin_call(D3C*c,const char*name){
 /* current token is '(' */
 if(!d3_expect(c,'(',"expected ("))return 0;
 if(d3_eq(name,"peek8")||d3_eq(name,"peek16")||d3_eq(name,"peek32")||d3_eq(name,"peek64")||d3_eq(name,"alloc")||d3_eq(name,"free")||d3_eq(name,"push")){
  if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  int op=d3_eq(name,"peek8")?D3_PEEK8:d3_eq(name,"peek16")?D3_PEEK16:d3_eq(name,"peek32")?D3_PEEK32:d3_eq(name,"peek64")?D3_PEEK64:d3_eq(name,"alloc")?D3_ALLOC:d3_eq(name,"free")?D3_FREE:D3_UPUSH;
  d3_emit(c,op);return c->p->error[0]?0:1;
 }
 if(d3_eq(name,"poke8")||d3_eq(name,"poke16")||d3_eq(name,"poke32")||d3_eq(name,"poke64")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  d3_emit(c,d3_eq(name,"poke8")?D3_POKE8:d3_eq(name,"poke16")?D3_POKE16:d3_eq(name,"poke32")?D3_POKE32:D3_POKE64);return 1;
 }
 if(d3_eq(name,"pop")){
  if(!d3_expect(c,')',"expected )"))return 0;d3_emit(c,D3_UPOP);return 1;
 }
 if(d3_eq(name,"api")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,D3_API);return 1;
 }
 if(d3_eq(name,"native")){
  int argc=0;if(c->l.tok!=')'){
   if(!d3_expr(c))return 0;
   while(d3_accept(c,',')){if(argc>=6)return d3_fail(c,"native supports 6 args");if(!d3_expr(c))return 0;argc++;}
   /* first expression is function; remaining count = commas */
  }
  if(!d3_expect(c,')',"expected )"))return 0;
  D3Ins*i=d3_emit(c,D3_NATIVE);if(i)i->a=(d_u8)argc;return i!=0;
 }
 if(d3_eq(name,"family")){
  if(!d3_expr(c))return 0;int argc=1;if(d3_accept(c,',')){if(!d3_expr(c))return 0;argc=2;}if(!d3_expect(c,')',"expected )"))return 0;D3Ins*i=d3_emit(c,G3_FAMILY);if(i)i->a=(d_u8)argc;return i!=0;
 }
 if(d3_eq(name,"gene")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G3_GENE);return 1;
 }
 if(d3_eq(name,"poly")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G3_POLY);return 1;
 }
 if(d3_eq(name,"mut")||d3_eq(name,"mutate")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c))return 0;int argc=2;if(d3_accept(c,',')){if(!d3_expr(c))return 0;argc=3;}if(!d3_expect(c,')',"expected )"))return 0;D3Ins*i=d3_emit(c,G3_MUTATE);if(i)i->a=(d_u8)argc;return i!=0;
 }
 if(d3_eq(name,"breed")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c))return 0;int argc=3;if(d3_accept(c,',')){if(!d3_expr(c))return 0;argc=4;}if(!d3_expect(c,')',"expected )"))return 0;D3Ins*i=d3_emit(c,G3_BREED);if(i)i->a=(d_u8)argc;return i!=0;
 }
 if(d3_eq(name,"hash")){
  if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G3_HASH);return 1;
 }
 /* GAIA 2: unknowns, uncertainty, evidence, scientific containers and evolutionary search. */
 if(d3_eq(name,"unknown")){if(!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G2_UNKNOWN);return 1;}
 if(d3_eq(name,"isunknown")||d3_eq(name,"known")||d3_eq(name,"abs")||d3_eq(name,"ilo")||d3_eq(name,"ihi")||d3_eq(name,"imid")||d3_eq(name,"iwidth")||d3_eq(name,"vlen")||d3_eq(name,"vsum")||d3_eq(name,"vmean")||d3_eq(name,"vmin")||d3_eq(name,"vmax")||d3_eq(name,"mrows")||d3_eq(name,"mcols")||d3_eq(name,"mmean")||d3_eq(name,"popdna")||d3_eq(name,"popsize")||d3_eq(name,"rng")){
  if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  int op=d3_eq(name,"isunknown")?G2_ISUNKNOWN:d3_eq(name,"known")?G2_KNOWN:d3_eq(name,"abs")?G2_ABS:d3_eq(name,"ilo")?G2_ILO:d3_eq(name,"ihi")?G2_IHI:d3_eq(name,"imid")?G2_IMID:d3_eq(name,"iwidth")?G2_IWIDTH:d3_eq(name,"vlen")?G2_VLEN:d3_eq(name,"vsum")?G2_VSUM:d3_eq(name,"vmean")?G2_VMEAN:d3_eq(name,"vmin")?G2_VMIN:d3_eq(name,"vmax")?G2_VMAX:d3_eq(name,"mrows")?G2_MROWS:d3_eq(name,"mcols")?G2_MCOLS:d3_eq(name,"mmean")?G2_MMEAN:d3_eq(name,"popdna")?G2_POPDNA:d3_eq(name,"popsize")?G2_POPSIZE:G2_RNG;d3_emit(c,op);return 1;
 }
 if(d3_eq(name,"coalesce")||d3_eq(name,"min")||d3_eq(name,"max")||d3_eq(name,"qmul")||d3_eq(name,"qdiv")||d3_eq(name,"interval")||d3_eq(name,"surprise")||d3_eq(name,"vector")||d3_eq(name,"vget")||d3_eq(name,"vdot")||d3_eq(name,"population")||d3_eq(name,"matrix")||d3_eq(name,"icontains")){
  if(!d3_expr(c))return 0;int argc=1;if(d3_accept(c,',')){if(!d3_expr(c))return 0;argc=2;}if(!d3_expect(c,')',"expected )"))return 0;
  int op=d3_eq(name,"coalesce")?G2_COALESCE:d3_eq(name,"min")?G2_MIN:d3_eq(name,"max")?G2_MAX:d3_eq(name,"qmul")?G2_QMUL:d3_eq(name,"qdiv")?G2_QDIV:d3_eq(name,"interval")?G2_INTERVAL:d3_eq(name,"surprise")?G2_SURPRISE:d3_eq(name,"vector")?G2_VECTOR:d3_eq(name,"vget")?G2_VGET:d3_eq(name,"vdot")?G2_VDOT:d3_eq(name,"population")?G2_POP:d3_eq(name,"matrix")?G2_MATRIX:G2_ICONTAINS;
  if((op==G2_VECTOR)&&argc!=1)return d3_fail(c,"vector requires one argument");if(op!=G2_VECTOR&&argc!=2)return d3_fail(c,"builtin requires two arguments");d3_emit(c,op);return 1;
 }
 if(d3_eq(name,"clamp")||d3_eq(name,"support")||d3_eq(name,"falsify")||d3_eq(name,"vset")||d3_eq(name,"sample")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  d3_emit(c,d3_eq(name,"clamp")?G2_CLAMP:d3_eq(name,"support")?G2_SUPPORT:d3_eq(name,"falsify")?G2_FALSIFY:d3_eq(name,"vset")?G2_VSET:G2_SAMPLE);return 1;
 }
 if(d3_eq(name,"receipt")||d3_eq(name,"mean4")||d3_eq(name,"worst4")||d3_eq(name,"spread4")||d3_eq(name,"mget")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c))return 0;
  if(d3_eq(name,"mget")){if(!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G2_MGET);return 1;}
  if(!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,d3_eq(name,"receipt")?G2_RECEIPT:d3_eq(name,"mean4")?G2_MEAN4:d3_eq(name,"worst4")?G2_WORST4:G2_SPREAD4);return 1;
 }
 if(d3_eq(name,"mset")){if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G2_MSET);return 1;}
 if(d3_eq(name,"evolve_target")){if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G2_EVOLVE_TARGET);return 1;}
 if(d3_eq(name,"evolve_max")||d3_eq(name,"evolve_min")){if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,d3_eq(name,"evolve_max")?G2_EVOLVE_MAX:G2_EVOLVE_MIN);return 1;}
 if(d3_eq(name,"seekpoly")){if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G2_SEEKPOLY);return 1;}

 /* GAIA 2.1: IEEE floats, autodiff, tensors, Bayesian sampling, solvers, datasets, GPU. */
 if(d3_eq(name,"f32")||d3_eq(name,"f32tof64")||d3_eq(name,"itof64")||d3_eq(name,"f64toi")||d3_eq(name,"itof32")||d3_eq(name,"f32toi")||
    d3_eq(name,"fneg")||d3_eq(name,"fabs")||d3_eq(name,"fsqrt")||d3_eq(name,"dval")||d3_eq(name,"dgrad")||
    d3_eq(name,"trank")||d3_eq(name,"tlen")||d3_eq(name,"tsum")||d3_eq(name,"tmean")||
    d3_eq(name,"csv")||d3_eq(name,"tsv")||d3_eq(name,"loadcsv")||d3_eq(name,"loadtsv")||
    d3_eq(name,"printf64")||d3_eq(name,"printf32")){
  if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  int op=d3_eq(name,"f32")?G21_F32:d3_eq(name,"f32tof64")?G21_F32TOF64:d3_eq(name,"itof64")?G21_ITOF64:d3_eq(name,"f64toi")?G21_F64TOI:d3_eq(name,"itof32")?G21_ITOF32:d3_eq(name,"f32toi")?G21_F32TOI:
   d3_eq(name,"fneg")?G21_FNEG:d3_eq(name,"fabs")?G21_FABS:d3_eq(name,"fsqrt")?G21_FSQRT:d3_eq(name,"dval")?G21_DVAL:d3_eq(name,"dgrad")?G21_DGRAD:
   d3_eq(name,"trank")?G21_TRANK:d3_eq(name,"tlen")?G21_TLEN:d3_eq(name,"tsum")?G21_TSUM:d3_eq(name,"tmean")?G21_TMEAN:
   d3_eq(name,"csv")?G21_CSV:d3_eq(name,"tsv")?G21_TSV:d3_eq(name,"loadcsv")?G21_LOADCSV:d3_eq(name,"loadtsv")?G21_LOADTSV:d3_eq(name,"printf64")?G21_PRINTF64:G21_PRINTF32;
  d3_emit(c,op);return 1;
 }
 if(d3_eq(name,"fadd")||d3_eq(name,"fsub")||d3_eq(name,"fmul")||d3_eq(name,"fdiv")||d3_eq(name,"fmin")||d3_eq(name,"fmax")||
    d3_eq(name,"feq")||d3_eq(name,"flt")||d3_eq(name,"fle")||d3_eq(name,"fgt")||d3_eq(name,"fge")||
    d3_eq(name,"f32add")||d3_eq(name,"f32sub")||d3_eq(name,"f32mul")||d3_eq(name,"f32div")||
    d3_eq(name,"dual")||d3_eq(name,"dadd")||d3_eq(name,"dsub")||d3_eq(name,"dmul")||d3_eq(name,"ddiv")||
    d3_eq(name,"tdim")||d3_eq(name,"tget")||d3_eq(name,"tfill")||d3_eq(name,"posterior_sample")||d3_eq(name,"bayes_mean")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  int op=d3_eq(name,"fadd")?G21_FADD:d3_eq(name,"fsub")?G21_FSUB:d3_eq(name,"fmul")?G21_FMUL:d3_eq(name,"fdiv")?G21_FDIV:d3_eq(name,"fmin")?G21_FMIN:d3_eq(name,"fmax")?G21_FMAX:
   d3_eq(name,"feq")?G21_FEQ:d3_eq(name,"flt")?G21_FLT:d3_eq(name,"fle")?G21_FLE:d3_eq(name,"fgt")?G21_FGT:d3_eq(name,"fge")?G21_FGE:
   d3_eq(name,"f32add")?G21_F32ADD:d3_eq(name,"f32sub")?G21_F32SUB:d3_eq(name,"f32mul")?G21_F32MUL:d3_eq(name,"f32div")?G21_F32DIV:
   d3_eq(name,"dual")?G21_DUAL:d3_eq(name,"dadd")?G21_DADD:d3_eq(name,"dsub")?G21_DSUB:d3_eq(name,"dmul")?G21_DMUL:d3_eq(name,"ddiv")?G21_DDIV:
   d3_eq(name,"tdim")?G21_TDIM:d3_eq(name,"tget")?G21_TGET:d3_eq(name,"tfill")?G21_TFILL:d3_eq(name,"posterior_sample")?G21_POST_SAMPLE:G21_BAYES_MEAN;
  d3_emit(c,op);return 1;
 }
 if(d3_eq(name,"tensor1")){if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G21_TENSOR1);return 1;}
 if(d3_eq(name,"tensor2")){if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G21_TENSOR2);return 1;}
 if(d3_eq(name,"tensor3")){if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G21_TENSOR3);return 1;}
 if(d3_eq(name,"tensor4")){if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G21_TENSOR4);return 1;}
 if(d3_eq(name,"tset")||d3_eq(name,"taxpy")||d3_eq(name,"gpu_axpy")||d3_eq(name,"ode_euler")||d3_eq(name,"pde_heat1d")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  d3_emit(c,d3_eq(name,"tset")?G21_TSET:d3_eq(name,"taxpy")?G21_TAXPY:d3_eq(name,"gpu_axpy")?G21_GPU_AXPY:d3_eq(name,"ode_euler")?G21_ODE_EULER:G21_PDE_HEAT1D);return 1;
 }
 if(d3_eq(name,"mh_step")||d3_eq(name,"ode_rk4_linear")||d3_eq(name,"sde_em")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  d3_emit(c,d3_eq(name,"mh_step")?G21_MH_STEP:d3_eq(name,"ode_rk4_linear")?G21_ODE_RK4_LINEAR:G21_SDE_EM);return 1;
 }
 if(d3_eq(name,"gpu_backend")){if(!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G21_GPU_BACKEND);return 1;}
 return d3_fail(c,"unknown builtin call");
}

static int d3_primary(D3C*c){
 if(c->l.tok==T_NUM){D3Ins*i=d3_emit(c,D3_PUSHI);if(i)i->imm=c->l.num;d3_next(&c->l);return i!=0;}
 if(c->l.tok==T_FLOAT){D3Ins*i=d3_emit(c,D3_PUSHI);if(i)i->imm=(d_i64)c->l.fbits;d3_next(&c->l);return i!=0;}
 if(c->l.tok==T_STR){D3Ins*i=d3_emit(c,D3_PUSHS);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);return i!=0;}
 if(d3_accept(c,'(')){if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;return 1;}
 if(c->l.tok==T_ID){
  char name[80];d3_copy(name,c->l.text,80);d3_next(&c->l);
  int mid=d3_macro_find(c,name);if(mid>=0){D3Ins*i=d3_emit(c,c->macros[mid].isstr?D3_PUSHS:D3_PUSHI);if(!i)return 0;if(c->macros[mid].isstr)d3_copy(i->text,c->macros[mid].text,D3_TEXT);else i->imm=c->macros[mid].num;return 1;}
  if(d3_eq(name,"asm")){
   if(!d3_expect(c,'{',"expected { after asm"))return 0;D3Ins*i=d3_emit(c,D3_ASM);if(!i)return 0;int n=0;
   while(c->l.tok!=T_EOF&&c->l.tok!='}'){
    char tmp[160];d3_copy(tmp,c->l.text,160);
    if(c->l.tok==T_NUM&&tmp[0]==0){d3_i64str(c->l.num,tmp);}
    if(c->l.tok!=T_NUM&&c->l.tok!=T_ID)return d3_fail(c,"asm expects hex bytes");
    int L=d3_len(tmp);if(L!=2||d3_hex(tmp[0])<0||d3_hex(tmp[1])<0)return d3_fail(c,"asm bytes must be two hex digits");
    if(n>=D3_RAW)return d3_fail(c,"asm block too large");i->raw[n++]=(d_u8)((d3_hex(tmp[0])<<4)|d3_hex(tmp[1]));d3_next(&c->l);
   }
   if(!d3_expect(c,'}',"expected }"))return 0;i->n=(d_u16)n;return 1;
  }
  if(c->l.tok=='(')return d3_builtin_call(c,name);
  int id=d3_var(c,name);if(id<0)return 0;D3Ins*i=d3_emit(c,D3_LOAD);if(i)i->a=(d_u8)id;return i!=0;
 }
 return d3_fail(c,"expected expression");
}
static int d3_unary(D3C*c){if(d3_accept(c,'-')){if(!d3_unary(c))return 0;d3_emit(c,D3_NEG);return 1;}if(d3_accept(c,'!')){if(!d3_unary(c))return 0;d3_emit(c,D3_LNOT);return 1;}if(d3_accept(c,'~')){if(!d3_unary(c))return 0;d3_emit(c,D3_BNOT);return 1;}return d3_primary(c);}
static int d3_mul(D3C*c){if(!d3_unary(c))return 0;for(;;){int t=c->l.tok,op=0;if(t=='*')op=D3_MUL;else if(t=='/')op=D3_DIV;else if(t=='%')op=D3_MOD;else if(t==T_WEAVE)op=D3_WEAVE;else break;d3_next(&c->l);if(!d3_unary(c))return 0;d3_emit(c,op);}return 1;}
static int d3_add(D3C*c){if(!d3_mul(c))return 0;while(c->l.tok=='+'||c->l.tok=='-'){int op=c->l.tok=='+'?D3_ADD:D3_SUB;d3_next(&c->l);if(!d3_mul(c))return 0;d3_emit(c,op);}return 1;}
static int d3_shift(D3C*c){if(!d3_add(c))return 0;while(c->l.tok==T_SHL||c->l.tok==T_SHR){int op=c->l.tok==T_SHL?D3_SHL:D3_SHR;d3_next(&c->l);if(!d3_add(c))return 0;d3_emit(c,op);}return 1;}
static int d3_rel(D3C*c){if(!d3_shift(c))return 0;for(;;){int t=c->l.tok,op=0;if(t=='<')op=D3_LT;else if(t=='>')op=D3_GT;else if(t==T_LE)op=D3_LE;else if(t==T_GE)op=D3_GE;else break;d3_next(&c->l);if(!d3_shift(c))return 0;d3_emit(c,op);}return 1;}
static int d3_equality(D3C*c){if(!d3_rel(c))return 0;for(;;){int t=c->l.tok,op=0;if(t==T_EQEQ||t==T_MATCH)op=D3_EQ;else if(t==T_NE)op=D3_NE;else break;d3_next(&c->l);if(!d3_rel(c))return 0;d3_emit(c,op);}return 1;}
static int d3_band(D3C*c){if(!d3_equality(c))return 0;while(c->l.tok=='&'){d3_next(&c->l);if(!d3_equality(c))return 0;d3_emit(c,D3_BAND);}return 1;}
static int d3_bxor(D3C*c){if(!d3_band(c))return 0;while(c->l.tok=='^'||c->l.tok==T_RESONATE){d3_next(&c->l);if(!d3_band(c))return 0;d3_emit(c,D3_BXOR);}return 1;}
static int d3_bor(D3C*c){if(!d3_bxor(c))return 0;while(c->l.tok=='|'){d3_next(&c->l);if(!d3_bxor(c))return 0;d3_emit(c,D3_BOR);}return 1;}
static int d3_land(D3C*c){if(!d3_bor(c))return 0;while(c->l.tok==T_LAND){d3_next(&c->l);if(!d3_bor(c))return 0;d3_emit(c,D3_LAND);}return 1;}
static int d3_expr(D3C*c){if(!d3_land(c))return 0;while(c->l.tok==T_LOR){d3_next(&c->l);if(!d3_land(c))return 0;d3_emit(c,D3_LOR);}while(c->l.tok==T_FLOW||c->l.tok==T_EMIT){int op=c->l.tok==T_FLOW?D3_FLOW:D3_EMIT;d3_next(&c->l);if(!d3_land(c))return 0;d3_emit(c,op);}return 1;}

static int d3_semicolon(D3C*c){if(c->l.tok==';'){d3_next(&c->l);return 1;}return 1; /* newline is whitespace; semicolon optional */}

static int d3_statement(D3C*c){
 if(c->l.tok==T_EOF)return 1;
 D3Lex save=c->l;
 if(c->l.tok==T_ID){
  char name[80];d3_copy(name,c->l.text,80);d3_next(&c->l);
  if(c->l.tok==':'){int id=d3_label(c,name);if(id<0)return 0;c->p->labels[id].pc=c->p->ncode;d3_next(&c->l);return 1;}
  c->l=save;
 }
 if(d3_isid(c,"macro")){
  d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected macro name");char n[80];d3_copy(n,c->l.text,80);d3_next(&c->l);if(!d3_expect(c,'=',"expected ="))return 0;int id=d3_macro_new(c,n);if(id<0)return 0;
  if(c->l.tok==T_STR){c->macros[id].isstr=1;d3_copy(c->macros[id].text,c->l.text,D3_TEXT);d3_next(&c->l);}
  else if(c->l.tok==T_NUM||c->l.tok==T_FLOAT){c->macros[id].isstr=0;c->macros[id].num=c->l.tok==T_FLOAT?(d_i64)c->l.fbits:c->l.num;d3_next(&c->l);}
  else return d3_fail(c,"macro requires number or string");d3_semicolon(c);return 1;
 }
 if(d3_isid(c,"var")||d3_isid(c,"int")||d3_isid(c,"ptr")||d3_isid(c,"u8")||d3_isid(c,"u16")||d3_isid(c,"u32")||d3_isid(c,"u64")||d3_isid(c,"i64")||d3_isid(c,"dna")||d3_isid(c,"f32")||d3_isid(c,"f64")||d3_isid(c,"dual")||d3_isid(c,"tensor")||d3_isid(c,"q16")||d3_isid(c,"probability")||d3_isid(c,"quantity")||d3_isid(c,"vector")||d3_isid(c,"matrix")||d3_isid(c,"field")||d3_isid(c,"distribution")||d3_isid(c,"interval")||d3_isid(c,"unknown")||d3_isid(c,"population")||d3_isid(c,"environment")||d3_isid(c,"intervention")||d3_isid(c,"evidence")||d3_isid(c,"hypothesis")||d3_isid(c,"ensemble")||d3_isid(c,"timeseries")||d3_isid(c,"dataset")||d3_isid(c,"model")||d3_isid(c,"experiment")||d3_isid(c,"world")||d3_isid(c,"species")||d3_isid(c,"lineage")||d3_isid(c,"control")||d3_isid(c,"trace")||d3_isid(c,"counterexample")||d3_isid(c,"latent")){
  int default_unknown=d3_isid(c,"unknown");d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected variable name");char n[80];d3_copy(n,c->l.text,80);d3_next(&c->l);int id=d3_var(c,n);if(id<0)return 0;
  if(d3_accept(c,'=')){if(!d3_expr(c))return 0;}else{D3Ins*z=d3_emit(c,D3_PUSHI);if(z)z->imm=default_unknown?G2_UNKNOWN_VALUE:0;}
  D3Ins*s=d3_emit(c,D3_STORE);if(s)s->a=(d_u8)id;d3_semicolon(c);return s!=0;
 }
 if(d3_isid(c,"print")||d3_isid(c,"println")){
  int newline=d3_eq(c->l.text,"println");d3_next(&c->l);if(!d3_expect(c,'(',"expected ("))return 0;
  if(c->l.tok!=')')for(;;){int isstr=c->l.tok==T_STR||(c->l.tok==T_ID&&d3_macro_find(c,c->l.text)>=0&&c->macros[d3_macro_find(c,c->l.text)].isstr);if(!d3_expr(c))return 0;d3_emit(c,isstr?D3_PRINTS:D3_PRINTI);if(!d3_accept(c,','))break;}
  if(!d3_expect(c,')',"expected )"))return 0;if(newline){D3Ins*i=d3_emit(c,D3_PUSHS);if(i)d3_copy(i->text,"\r\n",D3_TEXT);d3_emit(c,D3_PRINTS);}d3_semicolon(c);return 1;
 }
 if(d3_isid(c,"printhex")){d3_next(&c->l);if(!d3_expect(c,'(',"expected (")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,G3_PRINTHEX);d3_semicolon(c);return 1;}
 if(d3_isid(c,"putc")){
  d3_next(&c->l);if(!d3_expect(c,'(',"expected (")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,D3_PUTC);d3_semicolon(c);return 1;
 }
 if(d3_isid(c,"goto")){
  d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected label");D3Ins*i=d3_emit(c,D3_JMP);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);d3_semicolon(c);return i!=0;
 }
 if(d3_isid(c,"call")||d3_isid(c,"gosub")){
  d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected label");D3Ins*i=d3_emit(c,D3_CALL);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);d3_semicolon(c);return i!=0;
 }
 if(d3_isid(c,"return")||d3_isid(c,"ret")){d3_next(&c->l);d3_emit(c,D3_RET);d3_semicolon(c);return 1;}
 if(d3_isid(c,"halt")||d3_isid(c,"end")){d3_next(&c->l);d3_emit(c,D3_HALT);d3_semicolon(c);return 1;}
 if(d3_isid(c,"if")){
  d3_next(&c->l);if(!d3_expr(c))return 0;if(!d3_isid(c,"goto"))return d3_fail(c,"if requires goto");d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected label");D3Ins*i=d3_emit(c,D3_JNZ);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);d3_semicolon(c);return i!=0;
 }
 /* assignment */
 if(c->l.tok==T_ID){
  D3Lex ss=c->l;char n[80];d3_copy(n,c->l.text,80);d3_next(&c->l);
  if(c->l.tok=='='){d3_next(&c->l);if(!d3_expr(c))return 0;int id=d3_var(c,n);D3Ins*i=d3_emit(c,D3_STORE);if(i)i->a=(d_u8)id;d3_semicolon(c);return i!=0;}
  c->l=ss;
 }
 /* expression statement, including asm{}, poke(), free(), native(), etc. */
 if(!d3_expr(c))return 0;d3_emit(c,D3_DROP);d3_semicolon(c);return 1;
}

static int d3_compile(D3Program*p,const char*src){
 d_u8*z=(d_u8*)p;for(int i=0;i<(int)sizeof(*p);i++)z[i]=0;D3C c;c.p=p;c.nmacros=0;c.l.src=src;c.l.p=0;c.l.line=1;d3_next(&c.l);
 while(c.l.tok!=T_EOF&&!p->error[0])if(!d3_statement(&c))break;
 if(p->error[0])return 0;
 /* patch labels */
 for(int i=0;i<p->ncode;i++)if(p->code[i].op==D3_JMP||p->code[i].op==D3_JZ||p->code[i].op==D3_JNZ||p->code[i].op==D3_CALL){int id=-1;for(int j=0;j<p->nlabels;j++)if(d3_eq(p->labels[j].name,p->code[i].text)){id=j;break;}if(id<0||p->labels[id].pc<0){p->error_line=0;d3_copy(p->error,"unknown label",160);return 0;}p->code[i].target=p->labels[id].pc;}
 return 1;
}

/* ---------- VM ---------- */
typedef struct {
 void (*out)(void*ctx,const char*s);
 void (*putc_)(void*ctx,char c);
 void* (*alloc)(void*ctx,d_u64 n);
 void (*free_)(void*ctx,void*p);
 d_u64 (*api)(void*ctx,const char*dll,const char*name);
 void* ctx;
 /* Optional science adapters. Existing freestanding hosts may leave these zero. */
 int (*gpu_axpy)(void*ctx,void*y,d_u64 alpha_bits,void*x);
 int (*gpu_available)(void*ctx);
 d_u64 (*read_text)(void*ctx,const char*path);
} D3Host;


static d_i64 g21_f64toi_safe(d_u64 bits){
 G21F64 q;q.u=bits;d_u64 e=(q.u>>52)&0x7ffULL;if(e==0x7ffULL)return G2_UNKNOWN_VALUE;
 double x=q.f;if(x>9223372036854774784.0)return (d_i64)0x7fffffffffffffffULL;if(x<-9223372036854774784.0)return (d_i64)0x8000000000000001ULL;return (d_i64)x;
}
static G21Tensor* g21_tensor_new(D3Host*h,d_u32 rank,d_u64 d0,d_u64 d1,d_u64 d2,d_u64 d3){
 if(!h||!h->alloc||rank<1||rank>4)return 0;d_u64 d[4]={d0,d1,d2,d3},n=1;
 for(d_u32 k=0;k<rank;k++){if(!d[k]||d[k]>16777216ULL||n>16777216ULL/d[k])return 0;n*=d[k];}
 if(n>16777216ULL)return 0;d_u64 bytes=(d_u64)sizeof(G21Tensor)+n*8ULL;G21Tensor*t=(G21Tensor*)h->alloc(h->ctx,bytes);if(!t)return 0;
 t->magic=G21_TENSOR_MAGIC;t->rank=rank;t->len=n;for(int k=0;k<4;k++)t->dim[k]=k<(int)rank?d[k]:0;
 d_u64*x=g21_tdata(t);for(d_u64 k=0;k<n;k++)x[k]=g21_f64bits(0.0);return t;
}
static int g21_tensor_axpy_cpu(G21Tensor*y,d_u64 abits,G21Tensor*x){
 if(!g21_tensor_ok(y)||!g21_tensor_ok(x)||y->len!=x->len)return 0;double a=g21_f64(abits);d_u64*yd=g21_tdata(y),*xd=g21_tdata(x);
 for(d_u64 k=0;k<y->len;k++)yd[k]=g21_f64bits(g21_f64(yd[k])+a*g21_f64(xd[k]));return 1;
}
static int g21_space(char c){return c==' '||c=='\t'||c=='\r';}
static d_u64 g21_parse_cell(const char*s,int n){
 int a=0,b=n;while(a<b&&g21_space(s[a]))a++;while(b>a&&g21_space(s[b-1]))b--;if(a>=b)return 0x7ff8000000000000ULL;
 char buf[80];int m=b-a;if(m>78)m=78;for(int i=0;i<m;i++)buf[i]=s[a+i];buf[m]=0;
 int j=0;if(buf[j]=='+'||buf[j]=='-')j++;if(!(d3_digit(buf[j])||buf[j]=='.'))return 0x7ff8000000000000ULL;
 return g21_f64bits(g21_parse_double(buf));
}
static G21Tensor* g21_dataset_parse(D3Host*h,const char*text,char sep){
 if(!text)return 0;d_u64 rows=0,cols=0;int p=0;
 while(text[p]){
  int start=p;while(text[p]&&text[p]!='\n')p++;int end=p;while(end>start&&(text[end-1]=='\r'||text[end-1]==' '||text[end-1]=='\t'))end--;
  int nonblank=0;for(int q=start;q<end;q++)if(!g21_space(text[q])){nonblank=1;break;}
  if(nonblank){d_u64 c=1;for(int q=start;q<end;q++)if(text[q]==sep)c++;if(!cols)cols=c;else if(c!=cols)return 0;rows++;}
  if(text[p]=='\n')p++;
 }
 if(!rows||!cols)return 0;G21Tensor*t=g21_tensor_new(h,2,rows,cols,0,0);if(!t)return 0;d_u64*out=g21_tdata(t),r=0;p=0;
 while(text[p]){
  int start=p;while(text[p]&&text[p]!='\n')p++;int end=p;while(end>start&&(text[end-1]=='\r'||text[end-1]==' '||text[end-1]=='\t'))end--;
  int nonblank=0;for(int q=start;q<end;q++)if(!g21_space(text[q])){nonblank=1;break;}
  if(nonblank){int cell=start;d_u64 c=0;for(int q=start;q<=end;q++)if(q==end||text[q]==sep){out[r*cols+c++]=g21_parse_cell(text+cell,q-cell);cell=q+1;}r++;}
  if(text[p]=='\n')p++;
 }
 return t;
}

typedef struct {
 d_i64 vars[D3_MAX_VARS]; d_i64 stack[D3_MAX_STACK]; int sp;
 int calls[D3_MAX_CALL],csp; d_i64 ustack[D3_MAX_USTACK];int usp;
 int error; char error_text[128];
} D3VM;
static void d3_vmfail(D3VM*v,const char*s){v->error=1;d3_copy(v->error_text,s,128);}
static void d3_push(D3VM*v,d_i64 x){if(v->sp>=D3_MAX_STACK)d3_vmfail(v,"stack overflow");else v->stack[v->sp++]=x;}
static d_i64 d3_pop(D3VM*v){if(v->sp<=0){d3_vmfail(v,"stack underflow");return 0;}return v->stack[--v->sp];}
static d_u64 d3_weave(d_u64 a,d_u64 b){d_u64 r=0;for(int i=0;i<32;i++){r|=((a>>i)&1ull)<<(2*i);r|=((b>>i)&1ull)<<(2*i+1);}return r;}
static d_u64 d3_native_call(d_u64 f,int n,d_u64*a){
 typedef d_u64 (D3_MS *F0)(void);typedef d_u64 (D3_MS *F1)(d_u64);typedef d_u64 (D3_MS *F2)(d_u64,d_u64);typedef d_u64 (D3_MS *F3)(d_u64,d_u64,d_u64);typedef d_u64 (D3_MS *F4)(d_u64,d_u64,d_u64,d_u64);typedef d_u64 (D3_MS *F5)(d_u64,d_u64,d_u64,d_u64,d_u64);typedef d_u64 (D3_MS *F6)(d_u64,d_u64,d_u64,d_u64,d_u64,d_u64);
 if(!f)return 0;switch(n){case 0:return ((F0)f)();case 1:return ((F1)f)(a[0]);case 2:return ((F2)f)(a[0],a[1]);case 3:return ((F3)f)(a[0],a[1],a[2]);case 4:return ((F4)f)(a[0],a[1],a[2],a[3]);case 5:return ((F5)f)(a[0],a[1],a[2],a[3],a[4]);default:return ((F6)f)(a[0],a[1],a[2],a[3],a[4],a[5]);}
}
static void d3_vmreset(D3VM*v){d_u8*z=(d_u8*)v;for(int i=0;i<(int)sizeof(*v);i++)z[i]=0;}
static int d3_exec(D3Program*p,D3Host*h,D3VM*v,int startpc,int maxsteps){
 int pc=startpc,steps=0;char nb[48];
 while(pc>=0&&pc<p->ncode&&!v->error&&steps++<maxsteps){D3Ins*i=&p->code[pc++];d_i64 a,b;switch(i->op){
  case D3_NOP:break;case D3_PUSHI:d3_push(v,i->imm);break;case D3_PUSHS:d3_push(v,(d_i64)(d_u64)(void*)i->text);break;
  case D3_LOAD:d3_push(v,v->vars[i->a]);break;case D3_STORE:v->vars[i->a]=d3_pop(v);break;case D3_DUP:a=d3_pop(v);d3_push(v,a);d3_push(v,a);break;case D3_DROP:(void)d3_pop(v);break;
  case D3_ADD:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:a+b);break;case D3_SUB:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:a-b);break;case D3_MUL:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:a*b);break;
  case D3_DIV:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:(b?a/b:0));break;case D3_MOD:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:(b?a%b:0));break;case D3_SHL:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)((d_u64)a<<(b&63)));break;case D3_SHR:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)((d_u64)a>>(b&63)));break;
  case D3_BAND:b=d3_pop(v);a=d3_pop(v);d3_push(v,a&b);break;case D3_BOR:b=d3_pop(v);a=d3_pop(v);d3_push(v,a|b);break;case D3_BXOR:b=d3_pop(v);a=d3_pop(v);d3_push(v,a^b);break;case D3_LAND:b=d3_pop(v);a=d3_pop(v);d3_push(v,(a&&b)?1:0);break;case D3_LOR:b=d3_pop(v);a=d3_pop(v);d3_push(v,(a||b)?1:0);break;
  case D3_EQ:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?0:a==b);break;case D3_NE:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?0:a!=b);break;case D3_LT:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?0:a<b);break;case D3_LE:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?0:a<=b);break;case D3_GT:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?0:a>b);break;case D3_GE:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?0:a>=b);break;
  case D3_NEG:a=d3_pop(v);d3_push(v,g2_is_unknown(a)?G2_UNKNOWN_VALUE:-a);break;case D3_LNOT:a=d3_pop(v);d3_push(v,g2_is_unknown(a)?0:!a);break;case D3_BNOT:d3_push(v,~d3_pop(v));break;case D3_WEAVE:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)d3_weave((d_u64)a,(d_u64)b));break;case D3_FLOW:{d_u64 fn=(d_u64)d3_pop(v),arg=(d_u64)d3_pop(v),aa[1]={arg};d3_push(v,(d_i64)d3_native_call(fn,1,aa));}break;case D3_EMIT:{d_u64 addr=(d_u64)d3_pop(v),val=(d_u64)d3_pop(v);*(volatile d_u64*)addr=val;d3_push(v,(d_i64)val);}break;
  case D3_PRINTI:a=d3_pop(v);if(g2_is_unknown(a)){if(h&&h->out)h->out(h->ctx,"UNKNOWN");}else{d3_i64str(a,nb);if(h&&h->out)h->out(h->ctx,nb);}break;case D3_PRINTS:a=d3_pop(v);if(h&&h->out)h->out(h->ctx,(const char*)(d_u64)a);break;case D3_PUTC:a=d3_pop(v);if(h&&h->putc_)h->putc_(h->ctx,(char)a);break;
  case D3_JMP:pc=i->target;break;case D3_JZ:if(!d3_pop(v))pc=i->target;break;case D3_JNZ:if(d3_pop(v))pc=i->target;break;case D3_CALL:if(v->csp>=D3_MAX_CALL)d3_vmfail(v,"call stack overflow");else{v->calls[v->csp++]=pc;pc=i->target;}break;case D3_RET:if(v->csp<=0)return 1;else pc=v->calls[--v->csp];break;case D3_HALT:return 1;
  case D3_PEEK8:a=d3_pop(v);d3_push(v,*(volatile d_u8*)(d_u64)a);break;case D3_PEEK16:a=d3_pop(v);d3_push(v,*(volatile d_u16*)(d_u64)a);break;case D3_PEEK32:a=d3_pop(v);d3_push(v,*(volatile d_u32*)(d_u64)a);break;case D3_PEEK64:a=d3_pop(v);d3_push(v,*(volatile d_u64*)(d_u64)a);break;
  case D3_POKE8:b=d3_pop(v);a=d3_pop(v);*(volatile d_u8*)(d_u64)a=(d_u8)b;d3_push(v,b);break;case D3_POKE16:b=d3_pop(v);a=d3_pop(v);*(volatile d_u16*)(d_u64)a=(d_u16)b;d3_push(v,b);break;case D3_POKE32:b=d3_pop(v);a=d3_pop(v);*(volatile d_u32*)(d_u64)a=(d_u32)b;d3_push(v,b);break;case D3_POKE64:b=d3_pop(v);a=d3_pop(v);*(volatile d_u64*)(d_u64)a=(d_u64)b;d3_push(v,b);break;
  case D3_ALLOC:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)(h&&h->alloc?h->alloc(h->ctx,(d_u64)a):0));break;case D3_FREE:a=d3_pop(v);if(h&&h->free_)h->free_(h->ctx,(void*)(d_u64)a);d3_push(v,0);break;
  case D3_API:{d_u64 sym=(d_u64)d3_pop(v),dll=(d_u64)d3_pop(v);d3_push(v,(d_i64)(h&&h->api?h->api(h->ctx,(const char*)dll,(const char*)sym):0));}break;
  case D3_NATIVE:{int n=i->a;d_u64 aa[6]={0,0,0,0,0,0};for(int k=n-1;k>=0;k--)aa[k]=(d_u64)d3_pop(v);d_u64 fn=(d_u64)d3_pop(v);d3_push(v,(d_i64)d3_native_call(fn,n,aa));}break;
  case D3_UPUSH:a=d3_pop(v);if(v->usp>=D3_MAX_USTACK)d3_vmfail(v,"user stack overflow");else{v->ustack[v->usp++]=a;d3_push(v,a);}break;case D3_UPOP:if(v->usp<=0)d3_vmfail(v,"user stack underflow");else d3_push(v,v->ustack[--v->usp]);break;
  case D3_ASM:{int n=i->n;if(!h||!h->alloc||!h->free_){d3_push(v,0);break;}d_u8*m=(d_u8*)h->alloc(h->ctx,(d_u64)n+16);if(!m){d3_push(v,0);break;}for(int k=0;k<n;k++)m[k]=i->raw[k];if(!n||m[n-1]!=0xC3)m[n++]=0xC3;d_u64 r=((d_u64(D3_MS*)(void))m)();h->free_(h->ctx,m);d3_push(v,(d_i64)r);}break;
  case G3_FAMILY:{d_u32 seed=0x47414941u;if(i->a==2)seed=(d_u32)d3_pop(v);d_u32 f=(d_u32)d3_pop(v);d3_push(v,(d_i64)(d_u64)g3_atlas_dna(f,seed));}break;
  case G3_GENE:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)g3_gene16((d_u32)a,(d_u32)b));break;
  case G3_POLY:{d_u32 count=(d_u32)d3_pop(v),start=(d_u32)d3_pop(v),dna=(d_u32)d3_pop(v);d3_push(v,(d_i64)g3_poly16(dna,start,count));}break;
  case G3_MUTATE:{d_u32 seed=0xA17Au;if(i->a==3)seed=(d_u32)d3_pop(v);d_u32 rate=(d_u32)d3_pop(v),dna=(d_u32)d3_pop(v);d3_push(v,(d_i64)(d_u64)g3_mutate(dna,rate,seed));}break;
  case G3_BREED:{d_u32 seed=0xB9EEDu;if(i->a==4)seed=(d_u32)d3_pop(v);d_u32 rate=(d_u32)d3_pop(v),bb=(d_u32)d3_pop(v),aa=(d_u32)d3_pop(v);d3_push(v,(d_i64)(d_u64)g3_breed(aa,bb,rate,seed));}break;
  case G3_HASH:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g3_hash_string((const char*)(d_u64)a));break;
  case G3_PRINTHEX:a=d3_pop(v);g3_hex64((d_u64)a,nb);if(h&&h->out)h->out(h->ctx,nb);break;
  case G2_UNKNOWN:d3_push(v,G2_UNKNOWN_VALUE);break;
  case G2_ISUNKNOWN:a=d3_pop(v);d3_push(v,g2_is_unknown(a));break;case G2_KNOWN:a=d3_pop(v);d3_push(v,!g2_is_unknown(a));break;
  case G2_COALESCE:b=d3_pop(v);a=d3_pop(v);d3_push(v,g2_is_unknown(a)?b:a);break;
  case G2_ABS:a=d3_pop(v);d3_push(v,g2_abs64(a));break;case G2_MIN:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:(a<b?a:b));break;case G2_MAX:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:(a>b?a:b));break;
  case G2_CLAMP:{d_i64 hi=d3_pop(v),lo=d3_pop(v),x=d3_pop(v);d3_push(v,(g2_is_unknown(x)||g2_is_unknown(lo)||g2_is_unknown(hi))?G2_UNKNOWN_VALUE:(x<lo?lo:(x>hi?hi:x)));}break;
  case G2_QMUL:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b))?G2_UNKNOWN_VALUE:(d_i64)(((a*b)+(1<<15))>>16));break;
  case G2_QDIV:b=d3_pop(v);a=d3_pop(v);d3_push(v,(g2_is_unknown(a)||g2_is_unknown(b)||!b)?G2_UNKNOWN_VALUE:(d_i64)((a<<16)/b));break;
  case G2_INTERVAL:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)g2_interval_pack(a,b));break;case G2_ILO:a=d3_pop(v);d3_push(v,g2_interval_lo((d_u64)a));break;case G2_IHI:a=d3_pop(v);d3_push(v,g2_interval_hi((d_u64)a));break;case G2_IMID:a=d3_pop(v);d3_push(v,((d_i64)g2_interval_lo((d_u64)a)+(d_i64)g2_interval_hi((d_u64)a))/2);break;case G2_IWIDTH:a=d3_pop(v);d3_push(v,(d_i64)g2_interval_hi((d_u64)a)-(d_i64)g2_interval_lo((d_u64)a));break;
  case G2_ICONTAINS:{d_i64 x=d3_pop(v);d_u64 in=(d_u64)d3_pop(v);d3_push(v,x>=g2_interval_lo(in)&&x<=g2_interval_hi(in));}break;
  case G2_SURPRISE:b=d3_pop(v);a=d3_pop(v);{d_u64 d=g2_uabsdiff(a,b);d3_push(v,d==~0ULL?G2_UNKNOWN_VALUE:(d_i64)d);}break;
  case G2_SUPPORT:{d_i64 tol=d3_pop(v),obs=d3_pop(v),pred=d3_pop(v);d_u64 d=g2_uabsdiff(pred,obs);if(d==~0ULL)d3_push(v,G2_UNKNOWN_VALUE);else if(tol<=0)d3_push(v,d?0:65535);else if(d>=(d_u64)tol)d3_push(v,0);else d3_push(v,(d_i64)(65535ULL-((d*65535ULL)/(d_u64)tol)));}break;
  case G2_FALSIFY:{d_i64 tol=d3_pop(v),obs=d3_pop(v),pred=d3_pop(v);d_u64 d=g2_uabsdiff(pred,obs);d3_push(v,d!=~0ULL&&d>(d_u64)(tol<0?-tol:tol));}break;
  case G2_RECEIPT:{d_u32 d=(d_u32)d3_pop(v),cc=(d_u32)d3_pop(v),bb=(d_u32)d3_pop(v),aa=(d_u32)d3_pop(v);d_u32 r=g3_mix32(aa^0xA341316Cu);r=g3_mix32(r^bb^0xC8013EA4u);r=g3_mix32(r^cc^0xAD90777Du);r=g3_mix32(r^d^0x7E95761Eu);d3_push(v,(d_i64)(d_u64)r);}break;
  case G2_VECTOR:{d_i64 n=d3_pop(v);if(n<0||n>1048576||!h||!h->alloc){d3_push(v,0);break;}d_u64*mem=(d_u64*)h->alloc(h->ctx,(d_u64)(n+1)*8);if(!mem){d3_push(v,0);break;}mem[0]=(d_u64)n;for(d_i64 k=0;k<n;k++)mem[k+1]=0;d3_push(v,(d_i64)(d_u64)(void*)mem);}break;
  case G2_VLEN:a=d3_pop(v);d3_push(v,a?(d_i64)(*(d_u64*)(d_u64)a):0);break;
  case G2_VGET:{d_i64 ix=d3_pop(v);d_u64*mem=(d_u64*)(d_u64)d3_pop(v);if(!mem||ix<0||(d_u64)ix>=mem[0])d3_push(v,G2_UNKNOWN_VALUE);else d3_push(v,(d_i64)mem[ix+1]);}break;
  case G2_VSET:{d_i64 val=d3_pop(v),ix=d3_pop(v);d_u64*mem=(d_u64*)(d_u64)d3_pop(v);if(!mem||ix<0||(d_u64)ix>=mem[0])d3_push(v,G2_UNKNOWN_VALUE);else{mem[ix+1]=(d_u64)val;d3_push(v,val);}}break;
  case G2_VSUM:case G2_VMEAN:case G2_VMIN:case G2_VMAX:{d_u64*mem=(d_u64*)(d_u64)d3_pop(v);if(!mem||!mem[0]){d3_push(v,G2_UNKNOWN_VALUE);break;}d_u64 n=mem[0];d_i64 r=(d_i64)mem[1];if(i->op==G2_VSUM||i->op==G2_VMEAN){r=0;for(d_u64 k=0;k<n;k++)r+=(d_i64)mem[k+1];if(i->op==G2_VMEAN)r/=(d_i64)n;}else for(d_u64 k=1;k<n;k++){d_i64 x=(d_i64)mem[k+1];if(i->op==G2_VMIN){if(x<r)r=x;}else if(x>r)r=x;}d3_push(v,r);}break;
  case G2_VDOT:{d_u64*mb=(d_u64*)(d_u64)d3_pop(v),*ma=(d_u64*)(d_u64)d3_pop(v);if(!ma||!mb){d3_push(v,G2_UNKNOWN_VALUE);break;}d_u64 n=ma[0]<mb[0]?ma[0]:mb[0];d_i64 r=0;for(d_u64 k=0;k<n;k++)r+=(d_i64)ma[k+1]*(d_i64)mb[k+1];d3_push(v,r);}break;
  case G2_MATRIX:{d_i64 cols=d3_pop(v),rows=d3_pop(v);if(rows<0||cols<0||rows>4096||cols>4096||!h||!h->alloc){d3_push(v,0);break;}d_u64 n=(d_u64)rows*(d_u64)cols,*mem=(d_u64*)h->alloc(h->ctx,(n+2)*8);if(!mem){d3_push(v,0);break;}mem[0]=(d_u64)rows;mem[1]=(d_u64)cols;for(d_u64 k=0;k<n;k++)mem[k+2]=0;d3_push(v,(d_i64)(d_u64)(void*)mem);}break;
  case G2_MROWS:a=d3_pop(v);d3_push(v,a?(d_i64)(*(d_u64*)(d_u64)a):0);break;case G2_MCOLS:a=d3_pop(v);d3_push(v,a?(d_i64)(((d_u64*)(d_u64)a)[1]):0);break;
  case G2_MGET:{d_i64 col=d3_pop(v),row=d3_pop(v);d_u64*mem=(d_u64*)(d_u64)d3_pop(v);if(!mem||row<0||col<0||(d_u64)row>=mem[0]||(d_u64)col>=mem[1])d3_push(v,G2_UNKNOWN_VALUE);else d3_push(v,(d_i64)mem[2+(d_u64)row*mem[1]+(d_u64)col]);}break;
  case G2_MSET:{d_i64 val=d3_pop(v),col=d3_pop(v),row=d3_pop(v);d_u64*mem=(d_u64*)(d_u64)d3_pop(v);if(!mem||row<0||col<0||(d_u64)row>=mem[0]||(d_u64)col>=mem[1])d3_push(v,G2_UNKNOWN_VALUE);else{mem[2+(d_u64)row*mem[1]+(d_u64)col]=(d_u64)val;d3_push(v,val);}}break;
  case G2_MMEAN:{d_u64*mem=(d_u64*)(d_u64)d3_pop(v);if(!mem||!mem[0]||!mem[1]){d3_push(v,G2_UNKNOWN_VALUE);break;}d_u64 n=mem[0]*mem[1];d_i64 r=0;for(d_u64 k=0;k<n;k++)r+=(d_i64)mem[k+2];d3_push(v,r/(d_i64)n);}break;
  case G2_POP:{d_u32 size=(d_u32)d3_pop(v),dna=(d_u32)d3_pop(v);d3_push(v,(d_i64)g2_population_pack(dna,size));}break;case G2_POPDNA:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g2_population_dna((d_u64)a));break;case G2_POPSIZE:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g2_population_size((d_u64)a));break;
  case G2_EVOLVE_TARGET:{d_u32 seed=(d_u32)d3_pop(v),trials=(d_u32)d3_pop(v),rate=(d_u32)d3_pop(v),target=(d_u32)d3_pop(v),locus=(d_u32)d3_pop(v);d_u64 pop=(d_u64)d3_pop(v);d_u32 dna=g2_search_gene(g2_population_dna(pop),locus,target,trials,rate,seed,0);d3_push(v,(d_i64)g2_population_pack(dna,g2_population_size(pop)));}break;
  case G2_EVOLVE_MAX:case G2_EVOLVE_MIN:{d_u32 seed=(d_u32)d3_pop(v),trials=(d_u32)d3_pop(v),rate=(d_u32)d3_pop(v),locus=(d_u32)d3_pop(v);d_u64 pop=(d_u64)d3_pop(v);d_u32 dna=g2_search_gene(g2_population_dna(pop),locus,0,trials,rate,seed,i->op==G2_EVOLVE_MAX?1:2);d3_push(v,(d_i64)g2_population_pack(dna,g2_population_size(pop)));}break;
  case G2_SEEKPOLY:{d_u32 seed=(d_u32)d3_pop(v),rate=(d_u32)d3_pop(v),trials=(d_u32)d3_pop(v),target=(d_u32)d3_pop(v),count=(d_u32)d3_pop(v),start=(d_u32)d3_pop(v),dna=(d_u32)d3_pop(v);d3_push(v,(d_i64)(d_u64)g2_search_poly(dna,start,count,target,trials,rate,seed));}break;
  case G2_MEAN4:case G2_WORST4:case G2_SPREAD4:{d_i64 q[4];for(int k=3;k>=0;k--)q[k]=d3_pop(v);if(g2_is_unknown(q[0])||g2_is_unknown(q[1])||g2_is_unknown(q[2])||g2_is_unknown(q[3])){d3_push(v,G2_UNKNOWN_VALUE);break;}d_i64 mn=q[0],mx=q[0],sum=0;for(int k=0;k<4;k++){if(q[k]<mn)mn=q[k];if(q[k]>mx)mx=q[k];sum+=q[k];}d3_push(v,i->op==G2_MEAN4?sum/4:(i->op==G2_WORST4?mn:mx-mn));}break;
  case G2_RNG:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g3_mix32((d_u32)a));break;
  case G2_SAMPLE:{d_i64 hi=d3_pop(v),lo=d3_pop(v),seed=d3_pop(v);if(hi<lo){d_i64 t=hi;hi=lo;lo=t;}d_u64 span=(d_u64)(hi-lo)+1;d3_push(v,lo+(d_i64)((d_u64)g3_mix32((d_u32)seed)%span));}break;
  /* GAIA 2.1 IEEE floating point. Float values are stored as raw IEEE bits in VM slots. */
  case G21_F32:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g21_f32bits((float)g21_f64((d_u64)a)));break;
  case G21_F32TOF64:a=d3_pop(v);d3_push(v,(d_i64)g21_f64bits((double)g21_f32((d_u32)a)));break;
  case G21_ITOF64:a=d3_pop(v);d3_push(v,(d_i64)g21_f64bits((double)a));break;
  case G21_F64TOI:a=d3_pop(v);d3_push(v,g21_f64toi_safe((d_u64)a));break;
  case G21_ITOF32:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g21_f32bits((float)a));break;
  case G21_F32TOI:a=d3_pop(v);d3_push(v,g21_f64toi_safe(g21_f64bits((double)g21_f32((d_u32)a))));break;
  case G21_FADD:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)g21_f64bits(g21_f64((d_u64)a)+g21_f64((d_u64)b)));break;
  case G21_FSUB:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)g21_f64bits(g21_f64((d_u64)a)-g21_f64((d_u64)b)));break;
  case G21_FMUL:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)g21_f64bits(g21_f64((d_u64)a)*g21_f64((d_u64)b)));break;
  case G21_FDIV:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)g21_f64bits(g21_f64((d_u64)a)/g21_f64((d_u64)b)));break;
  case G21_FNEG:a=d3_pop(v);d3_push(v,(d_i64)((d_u64)a^0x8000000000000000ULL));break;
  case G21_FABS:a=d3_pop(v);d3_push(v,(d_i64)((d_u64)a&0x7fffffffffffffffULL));break;
  case G21_FSQRT:a=d3_pop(v);d3_push(v,(d_i64)g21_f64bits(g21_sqrt(g21_f64((d_u64)a))));break;
  case G21_FMIN:case G21_FMAX:{double y=g21_f64((d_u64)d3_pop(v)),x=g21_f64((d_u64)d3_pop(v));double r=(x!=x)?x:((y!=y)?y:(i->op==G21_FMIN?(x<y?x:y):(x>y?x:y)));d3_push(v,(d_i64)g21_f64bits(r));}break;
  case G21_FEQ:case G21_FLT:case G21_FLE:case G21_FGT:case G21_FGE:{double y=g21_f64((d_u64)d3_pop(v)),x=g21_f64((d_u64)d3_pop(v));int r=i->op==G21_FEQ?(x==y):i->op==G21_FLT?(x<y):i->op==G21_FLE?(x<=y):i->op==G21_FGT?(x>y):(x>=y);d3_push(v,r);}break;
  case G21_F32ADD:case G21_F32SUB:case G21_F32MUL:case G21_F32DIV:{float y=g21_f32((d_u32)d3_pop(v)),x=g21_f32((d_u32)d3_pop(v));float r=i->op==G21_F32ADD?x+y:i->op==G21_F32SUB?x-y:i->op==G21_F32MUL?x*y:x/y;d3_push(v,(d_i64)(d_u64)g21_f32bits(r));}break;
  case G21_PRINTF64:a=d3_pop(v);g21_f64str((d_u64)a,nb);if(h&&h->out)h->out(h->ctx,nb);d3_push(v,a);break;
  case G21_PRINTF32:a=d3_pop(v);g21_f64str(g21_f64bits((double)g21_f32((d_u32)a)),nb);if(h&&h->out)h->out(h->ctx,nb);d3_push(v,a);break;

  /* Forward-mode automatic differentiation: packed IEEE-f32 dual numbers (value, derivative). */
  case G21_DUAL:{d_u32 dg=(d_u32)d3_pop(v),vv=(d_u32)d3_pop(v);d3_push(v,(d_i64)g21_dual(vv,dg));}break;
  case G21_DVAL:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g21_dval((d_u64)a));break;
  case G21_DGRAD:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)g21_dgrad((d_u64)a));break;
  case G21_DADD:case G21_DSUB:case G21_DMUL:case G21_DDIV:{
   d_u64 db=(d_u64)d3_pop(v),da=(d_u64)d3_pop(v);float av=g21_f32(g21_dval(da)),ad=g21_f32(g21_dgrad(da)),bv=g21_f32(g21_dval(db)),bd=g21_f32(g21_dgrad(db)),rv,rd;
   if(i->op==G21_DADD){rv=av+bv;rd=ad+bd;}else if(i->op==G21_DSUB){rv=av-bv;rd=ad-bd;}else if(i->op==G21_DMUL){rv=av*bv;rd=ad*bv+av*bd;}else{rv=av/bv;rd=(ad*bv-av*bd)/(bv*bv);}
   d3_push(v,(d_i64)g21_dual(g21_f32bits(rv),g21_f32bits(rd)));
  }break;

  /* Rank-1..4 contiguous IEEE-f64 tensors. Indices are flat; shape is queried with tdim(). */
  case G21_TENSOR1:{d_u64 d0=(d_u64)d3_pop(v);d3_push(v,(d_i64)(d_u64)(void*)g21_tensor_new(h,1,d0,0,0,0));}break;
  case G21_TENSOR2:{d_u64 d1=(d_u64)d3_pop(v),d0=(d_u64)d3_pop(v);d3_push(v,(d_i64)(d_u64)(void*)g21_tensor_new(h,2,d0,d1,0,0));}break;
  case G21_TENSOR3:{d_u64 d2=(d_u64)d3_pop(v),d1=(d_u64)d3_pop(v),d0=(d_u64)d3_pop(v);d3_push(v,(d_i64)(d_u64)(void*)g21_tensor_new(h,3,d0,d1,d2,0));}break;
  case G21_TENSOR4:{d_u64 d3=(d_u64)d3_pop(v),d2=(d_u64)d3_pop(v),d1=(d_u64)d3_pop(v),d0=(d_u64)d3_pop(v);d3_push(v,(d_i64)(d_u64)(void*)g21_tensor_new(h,4,d0,d1,d2,d3));}break;
  case G21_TRANK:a=d3_pop(v);{G21Tensor*t=(G21Tensor*)(d_u64)a;d3_push(v,g21_tensor_ok(t)?t->rank:0);}break;
  case G21_TLEN:a=d3_pop(v);{G21Tensor*t=(G21Tensor*)(d_u64)a;d3_push(v,g21_tensor_ok(t)?(d_i64)t->len:0);}break;
  case G21_TDIM:{d_i64 ax=d3_pop(v);G21Tensor*t=(G21Tensor*)(d_u64)d3_pop(v);d3_push(v,g21_tensor_ok(t)&&ax>=0&&ax<(d_i64)t->rank?(d_i64)t->dim[ax]:G2_UNKNOWN_VALUE);}break;
  case G21_TGET:{d_i64 ix=d3_pop(v);G21Tensor*t=(G21Tensor*)(d_u64)d3_pop(v);d3_push(v,g21_tensor_ok(t)&&ix>=0&&(d_u64)ix<t->len?(d_i64)g21_tdata(t)[ix]:G2_UNKNOWN_VALUE);}break;
  case G21_TSET:{d_u64 val=(d_u64)d3_pop(v);d_i64 ix=d3_pop(v);G21Tensor*t=(G21Tensor*)(d_u64)d3_pop(v);if(g21_tensor_ok(t)&&ix>=0&&(d_u64)ix<t->len){g21_tdata(t)[ix]=val;d3_push(v,(d_i64)val);}else d3_push(v,G2_UNKNOWN_VALUE);}break;
  case G21_TFILL:{d_u64 val=(d_u64)d3_pop(v);G21Tensor*t=(G21Tensor*)(d_u64)d3_pop(v);if(g21_tensor_ok(t)){d_u64*d=g21_tdata(t);for(d_u64 k=0;k<t->len;k++)d[k]=val;d3_push(v,(d_i64)(d_u64)(void*)t);}else d3_push(v,0);}break;
  case G21_TSUM:case G21_TMEAN:{G21Tensor*t=(G21Tensor*)(d_u64)d3_pop(v);if(!g21_tensor_ok(t)||!t->len){d3_push(v,(d_i64)0x7ff8000000000000ULL);break;}double z=0.0;d_u64*d=g21_tdata(t);for(d_u64 k=0;k<t->len;k++)z+=g21_f64(d[k]);if(i->op==G21_TMEAN)z/=(double)t->len;d3_push(v,(d_i64)g21_f64bits(z));}break;
  case G21_TAXPY:{G21Tensor*x=(G21Tensor*)(d_u64)d3_pop(v);d_u64 alpha=(d_u64)d3_pop(v);G21Tensor*y=(G21Tensor*)(d_u64)d3_pop(v);d3_push(v,g21_tensor_axpy_cpu(y,alpha,x));}break;

  /* Compact Bayesian primitives: weighted posterior sampling, posterior mean, Metropolis accept/reject. */
  case G21_POST_SAMPLE:{d_u32 seed=(d_u32)d3_pop(v);G21Tensor*w=(G21Tensor*)(d_u64)d3_pop(v);if(!g21_tensor_ok(w)||w->rank!=1||!w->len){d3_push(v,G2_UNKNOWN_VALUE);break;}double total=0.0;d_u64*wd=g21_tdata(w);for(d_u64 k=0;k<w->len;k++){double q=g21_f64(wd[k]);if(q>0.0&&q==q)total+=q;}if(!(total>0.0)){d3_push(v,G2_UNKNOWN_VALUE);break;}double u=g21_u01(seed)*total,acc=0.0;d_u64 pick=w->len-1;for(d_u64 k=0;k<w->len;k++){double q=g21_f64(wd[k]);if(q>0.0&&q==q)acc+=q;if(u<=acc){pick=k;break;}}d3_push(v,(d_i64)pick);}break;
  case G21_BAYES_MEAN:{G21Tensor*w=(G21Tensor*)(d_u64)d3_pop(v),*x=(G21Tensor*)(d_u64)d3_pop(v);if(!g21_tensor_ok(w)||!g21_tensor_ok(x)||w->len!=x->len||!w->len){d3_push(v,(d_i64)0x7ff8000000000000ULL);break;}double sw=0.0,sx=0.0;d_u64*wd=g21_tdata(w),*xd=g21_tdata(x);for(d_u64 k=0;k<w->len;k++){double q=g21_f64(wd[k]);if(q>0.0&&q==q){sw+=q;sx+=q*g21_f64(xd[k]);}}d3_push(v,(d_i64)g21_f64bits(sw>0.0?sx/sw:g21_f64(0x7ff8000000000000ULL)));}break;
  case G21_MH_STEP:{d_u32 seed=(d_u32)d3_pop(v);double wp=g21_f64((d_u64)d3_pop(v)),wc=g21_f64((d_u64)d3_pop(v));d_i64 proposal=d3_pop(v),current=d3_pop(v);int accept=0;if(wp>0.0&&wp==wp){if(!(wc>0.0)||wc!=wc)accept=1;else{double ratio=wp/wc;if(ratio>=1.0||g21_u01(seed)<ratio)accept=1;}}d3_push(v,accept?proposal:current);}break;

  /* Solvers: Euler/RK4 linear ODE, explicit heat PDE, deterministic Euler-Maruyama SDE. */
  case G21_ODE_EULER:{double dt=g21_f64((d_u64)d3_pop(v)),dy=g21_f64((d_u64)d3_pop(v)),y=g21_f64((d_u64)d3_pop(v));d3_push(v,(d_i64)g21_f64bits(y+dy*dt));}break;
  case G21_ODE_RK4_LINEAR:{d_i64 steps=d3_pop(v);double dt=g21_f64((d_u64)d3_pop(v)),bb=g21_f64((d_u64)d3_pop(v)),aa=g21_f64((d_u64)d3_pop(v)),y=g21_f64((d_u64)d3_pop(v));if(steps<0)steps=0;if(steps>1000000)steps=1000000;for(d_i64 k=0;k<steps;k++){double k1=aa*y+bb,k2=aa*(y+0.5*dt*k1)+bb,k3=aa*(y+0.5*dt*k2)+bb,k4=aa*(y+dt*k3)+bb;y+=dt*(k1+2.0*k2+2.0*k3+k4)/6.0;}d3_push(v,(d_i64)g21_f64bits(y));}break;
  case G21_PDE_HEAT1D:{d_i64 steps=d3_pop(v);double alpha=g21_f64((d_u64)d3_pop(v));G21Tensor*t=(G21Tensor*)(d_u64)d3_pop(v);if(!g21_tensor_ok(t)||t->rank!=1||alpha!=alpha||alpha<0.0||alpha>0.5||!h||!h->alloc||!h->free_){d3_push(v,0);break;}if(steps<0)steps=0;if(steps>100000)steps=100000;d_u64*nw=(d_u64*)h->alloc(h->ctx,t->len*8);if(!nw){d3_push(v,0);break;}d_u64*d=g21_tdata(t);for(d_i64 st=0;st<steps;st++){if(t->len){nw[0]=d[0];if(t->len>1)nw[t->len-1]=d[t->len-1];}for(d_u64 k=1;k+1<t->len;k++){double u=g21_f64(d[k]),l=g21_f64(d[k-1]),r=g21_f64(d[k+1]);nw[k]=g21_f64bits(u+alpha*(l-2.0*u+r));}for(d_u64 k=0;k<t->len;k++)d[k]=nw[k];}h->free_(h->ctx,nw);d3_push(v,(d_i64)(d_u64)(void*)t);}break;
  case G21_SDE_EM:{d_u32 seed=(d_u32)d3_pop(v);double dt=g21_f64((d_u64)d3_pop(v)),diff=g21_f64((d_u64)d3_pop(v)),drift=g21_f64((d_u64)d3_pop(v)),x=g21_f64((d_u64)d3_pop(v));if(dt<0.0){d3_push(v,(d_i64)0x7ff8000000000000ULL);break;}double z=g21_normal12(seed);d3_push(v,(d_i64)g21_f64bits(x+drift*dt+diff*g21_sqrt(dt)*z));}break;

  /* Numeric CSV/TSV adapters. File loading is an optional host service; parsing works everywhere. */
  case G21_CSV:case G21_TSV:{const char*text=(const char*)(d_u64)d3_pop(v);G21Tensor*t=g21_dataset_parse(h,text,i->op==G21_CSV?',':'\t');d3_push(v,(d_i64)(d_u64)(void*)t);}break;
  case G21_LOADCSV:case G21_LOADTSV:{const char*path=(const char*)(d_u64)d3_pop(v);if(!h||!h->read_text){d3_push(v,0);break;}d_u64 raw=h->read_text(h->ctx,path);if(!raw){d3_push(v,0);break;}G21Tensor*t=g21_dataset_parse(h,(const char*)(d_u64)raw,i->op==G21_LOADCSV?',':'\t');if(h->free_)h->free_(h->ctx,(void*)(d_u64)raw);d3_push(v,(d_i64)(d_u64)(void*)t);}break;

  /* GPU: portable AXPY kernel. OpenCL-capable hosts can override; otherwise same semantics run on CPU. */
  case G21_GPU_AXPY:{G21Tensor*x=(G21Tensor*)(d_u64)d3_pop(v);d_u64 alpha=(d_u64)d3_pop(v);G21Tensor*y=(G21Tensor*)(d_u64)d3_pop(v);int backend=0;if(h&&h->gpu_axpy&&(!h->gpu_available||h->gpu_available(h->ctx)))backend=h->gpu_axpy(h->ctx,y,alpha,x)?2:0;if(!backend&&g21_tensor_axpy_cpu(y,alpha,x))backend=1;d3_push(v,backend);}break;
  case G21_GPU_BACKEND:d3_push(v,(h&&h->gpu_axpy&&h->gpu_available&&h->gpu_available(h->ctx))?2:1);break;
  default:d3_vmfail(v,"bad opcode");break;
 }}
 if(steps>=maxsteps)d3_vmfail(v,"step limit");return v->error?0:1;
}
static int d3_run(D3Program*p,D3Host*h,D3VM*v,int maxsteps){d3_vmreset(v);return d3_exec(p,h,v,0,maxsteps);}

#endif
