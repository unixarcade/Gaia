# GAIA 0.1 // LANGUAGE SPECIFICATION

## 1. MODEL

Gaia has two coupled execution layers:

1. **Script layer** — a tiny line-oriented imperative language for names, context, loops and genome operations.
2. **Genome layer** — a deterministic 512-locus pleomorphic virtual machine.

A genome is an unsigned 32-bit value.

## 2. GENOME ADDRESSING

```text
families: 0..511
loci:     0..511
```

For locus `L`:

```text
domain   = floor(L / 16)
operator = L mod 16
operand  = gene(DNA,L) ∈ [0,1)
```

The upper nine bits of an atlas genome encode its lineage family.

## 3. DOMAINS

The 32 domains are the `GDOM` table in `gaia_core.js`.

## 4. OPERATORS

The 16 operators are the `GOP` table in `gaia_core.js`.

Each operator transforms the current domain register using gene strength, context, memory, phase and adjacent-domain coupling.

## 5. PLEOMORPHIC ECHO

After its primary instruction executes, each locus also applies a small deterministic influence to a secondary domain. This is Gaia's deliberate pleomorphism rule.

## 6. EXPRESSION

`express DNA N` performs `N` full sweeps over all 512 loci.

Expression returns:

```text
32 domain registers
32 domain memories
512 accumulated locus energies
visual phenotype
music phenotype
architecture phenotype
weather phenotype
chemistry phenotype
12 agent affinities
checksum
```

## 7. RECOMBINATION

`breed(A,B)` combines parent bitfields using a deterministic mask and then applies a small mutation pass.

## 8. MUTATION

`mutate(DNA,rate)` flips a rate-dependent number of bits using deterministic hashed positions. High mutation rates may remap the genome more aggressively.

## 9. SOURCE

Statements end with newline or `;`.

`//` begins a line comment.

Labels end with `:`.

## 10. CONTROL FLOW

```gaia
let i = 0;
loop:
print i;
i = i + 1;
if i < 8 goto loop;
halt;
```

## 11. DNA CONSTRUCTION

```gaia
dna a = family 53;
dna b = 0xDEADBEEF;
dna c = word "a sentence becomes a seed";
dna d = breed a b 0.08;
dna e = mutate d 0.12;
```

## 12. CONTEXT

```gaia
context water = .8;
context rain = .2;
context memory = .9;
```

Context values normally inhabit `[0,1]`, though the engine clamps derived signals as necessary.

## 13. INTROSPECTION

```gaia
emit a;
lens a 0 16;
atlas 3;
```

## 14. SOUND

```gaia
music a 32;
```

The browser maps DNA-derived rhythm, pitch, timbre, harmony and memory parameters into WebAudio events.

## 15. PRINCIPLE

```text
SOURCE DOES NOT DEFINE EVERY EFFECT.
DNA DOES NOT DEFINE EVERY CONDITION.
CONTEXT DOES NOT DEFINE EVERY OUTCOME.

EXPRESSION IS THEIR INTERSECTION.
```
