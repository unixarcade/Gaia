/* GAIA 0.1 // Pleomorphic DNA Programming Core
   Derived from the genomic machinery lineage of Captain Dot Gardenworld,
   with the game removed. Programs are genomes; execution is expression.
*/
(function(root,factory){
  const G=factory();
  if(typeof module!=='undefined'&&module.exports) module.exports=G;
  else root.Gaia=G;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const U=Math.PI*2;
const clamp=(x,a=-1,b=1)=>Math.max(a,Math.min(b,x));
const wrap=(n,m)=>(n%m+m)%m;
const mix=(a,b,t)=>a+(b-a)*t;
function M(x){x|=0;x=Math.imul(x^x>>>16,2146121005);x=Math.imul(x^x>>>15,2221713035);return(x^x>>>16)>>>0}
function hashString(s){let h=0x811c9dc5;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return M(h)}
const SYL='AE AR BI CA CE EL EN FI GA IO KA LI LU MI NA NO OR PA QU RA RE SA SE TA TH UL VE XI YA ZA'.split(' ');
const GDOM='SOIL WATER ROOT STEM LEAF BLOOM SEED FRUIT LIGHT HEAT COLD RAIN DROUGHT FROST WIND MINERAL MICROBE SYMBIOSIS ALLELOPATHY POLLINATOR GRAZER WISP ARCHITECTURE CISTERN NURSERY LANTERN ARCH RHYTHM PITCH TIMBRE HARMONY MEMORY'.split(' ');
const GOP='AMPLIFY DAMP STORE RELEASE SEEK AVOID LINK SPLIT CYCLE PULSE SLEEP WAKE MUTATE RESONATE MIRROR TRANSMUTE'.split(' ');
const PH='LUMINOUS MEDICINAL NECTAR-RICH SOILMAKER WATER-DRAWING CHORAL MIRRORLEAF NIGHT-BLOOMING FROSTWISE DROUGHTWISE SALTWISE DEEP-ROOTED AIR-ROOTED WIND-SAILING CRYSTALLINE THERMOGENIC ELECTRIC MAGNETIC SPORING FRUITING CARNIVOROUS SYMBIOTIC ALLELOPATHIC MYCORRHIZAL NITROGEN-FIXING PHOTOTROPIC MOON-TUNED SUN-TUNED AURORA-TUNED METEOR-FEEDING SELF-HEALING DORMANT FAST-CYCLING LONG-LIVED POLLINATOR-HOST WISP-HOST SCARAB-HOST GRAZER-PROOF RESONANT MEMORY-RINGED FRACTAL SPIRAL GLASSY VELVET PRISMATIC SHADOWLEAF GOLDEN ABYSSAL RAIN-CALLING ROOT-SHARING SEED-SAILING CLOUD-FEEDING HARMONIC IRIDESCENT HONEYED THORNED SOFT-SKINNED DREAMING'.split(' ');
const AGENTS='POLLINATOR SCARAB WISP GRAZER RAINMOTH SEEDFOX CHOIRBEETLE GLASSCRAWLER ROOTSPRITE SUNMITE MOONFLY GARDENER'.split(' ');
const LOC=512,FAM=512;
function tr(d,k){return M((d>>>0)^Math.imul(k+1,-1640531527))/4294967296}
function gene(d,k){return tr(d,800+(k&511))}
function poly(d,b,n=8){let s=0;for(let k=0;k<n;k++)s+=gene(d,b+k);return s/n}
function family(d){return (d>>>23)&511}
function atlasDNA(n,seed=0x47414941){return (((n&511)<<23)|(M((seed>>>0)^Math.imul((n&511)+1,0x45d9f3b))&0x7fffff))>>>0}
function dnaName(d){d>>>=0;return SYL[(d>>>27)%SYL.length]+SYL[(d>>>19)%SYL.length]+SYL[(d>>>11)%SYL.length]}
function hex(d){return (d>>>0).toString(16).padStart(8,'0').toUpperCase()}
function phen(d){let a=[];for(let k=0;k<PH.length;k++)if(gene(d,128+k)>.79+(k%5)*.025)a.push(PH[k]);return a.slice(0,5).join(' · ')||'QUIET'}
function mutate(d,rate=.12,seed=0xA17A){d>>>=0;rate=clamp(+rate||0,0,1);let h=M(d^(seed>>>0)^Math.floor(rate*0xffffffff));let bits=Math.max(1,Math.round(rate*16));for(let i=0;i<bits;i++){h=M(h+i*0x9e3779b9);d^=1<<(h&31)}if(rate>.65)d=M(d^h);return d>>>0}
function breed(a,b,seed=0xB9EED,rate=.08){a>>>=0;b>>>=0;let m=M((seed>>>0)^a^b),mask=M(m^0x9e3779b9),d=((a&mask)|(b&~mask))>>>0;return mutate(d,rate,m)}
function defaultContext(){let c={};for(let i=0;i<32;i++)c[GDOM[i].toLowerCase()]=.5;return Object.assign(c,{time:0,season:.5,pressure:.5,entropy:.15,mutation:.08})}
function ctxValue(ctx,d,l,dna,step){let k=GDOM[d].toLowerCase();let base=ctx[k];if(base===undefined)base=.5;let season=ctx.season===undefined?.5:ctx.season;let time=ctx.time===undefined?0:ctx.time;return clamp((base*2-1)+Math.sin(time*.07+step*.13+d*.47)*.12+(gene(dna,l+233)-.5)*.18+Math.sin(season*U+d)*.06,-1,1)}
function opApply(op,r,v,input,mem,next,phase,ctx){let s=(v-.5)*2;switch(op){
case 0:r+=s*(.08+Math.abs(input)*.05);break;                       // AMPLIFY
case 1:r*=1-(.025+v*.08);break;                                    // DAMP
case 2:mem=mix(mem,r,.08+v*.18);break;                              // STORE
case 3:r+=mem*(.03+v*.12);break;                                    // RELEASE
case 4:r+=Math.sign(input-r)*(.01+v*.05);break;                      // SEEK
case 5:r-=Math.sign(input-r)*(.008+v*.04);break;                     // AVOID
case 6:r+=next*(.015+v*.05);break;                                   // LINK
case 7:r=(r+Math.tanh(r+s)*(.3+v*.3))*.72;break;                    // SPLIT
case 8:r+=Math.sin(phase*U+v*U)*(.015+v*.035);break;                 // CYCLE
case 9:if(((phase*16)|0)%Math.max(1,1+((1-v)*7|0))===0)r+=s*.09;break;// PULSE
case 10:if(v>.55)r*=.94;break;                                      // SLEEP
case 11:if(v>.55)r+=input*.025;break;                                // WAKE
case 12:r+=(ctx.mutation||0)*s*.03;break;                            // MUTATE
case 13:r+=Math.sin((r+input+s)*U)*(.01+v*.035);break;               // RESONATE
case 14:r=mix(r,-r,.015+v*.035);break;                               // MIRROR
case 15:r=Math.tanh(r*(.9+v*.35)+s*.05);break;                       // TRANSMUTE
}return [clamp(r,-1.5,1.5),mem]}
function express(dna,steps=8,context,previous){dna>>>=0;steps=Math.max(1,Math.min(4096,steps|0));let ctx=Object.assign(defaultContext(),context||{}),regs=previous&&previous.regs?previous.regs.slice():new Array(32),mem=previous&&previous.mem?previous.mem.slice():new Array(32);for(let d=0;d<32;d++){if(regs[d]===undefined)regs[d]=(poly(dna,d*16,16)-.5)*.4;if(mem[d]===undefined)mem[d]=0}
let locusEnergy=new Float64Array(512);for(let step=0;step<steps;step++){let phase=(ctx.time+step)/Math.max(1,steps);for(let l=0;l<512;l++){let d=l>>4,op=l&15,v=gene(dna,l),input=ctxValue(ctx,d,l,dna,step),n=regs[(d+1)&31];let z=opApply(op,regs[d],v,input,mem[d],n,phase,ctx);regs[d]=z[0];mem[d]=z[1];locusEnergy[l]+=Math.abs(regs[d])*v;
// PLEOMORPHIC ECHO: every locus also whispers into a second deterministic organ.
let e=(d+1+((M(dna^l)>>>27)&7))&31;regs[e]=clamp(regs[e]+(v-.5)*.0025*(1+Math.abs(input)),-1.5,1.5)}ctx.time+=1}
let domains={};for(let d=0;d<32;d++)domains[GDOM[d]]=regs[d];
let affinities={};for(let i=0;i<AGENTS.length;i++)affinities[AGENTS[i]]=gene(dna,300+i)*.65+(regs[(16+i)%32]+1)*.175;
let visual={
 hue:wrap(150+(regs[8]+1)*80+(gene(dna,0)-.5)*120,360),
 symmetry:2+((gene(dna,46)*10)|0),
 branches:3+((gene(dna,70)*13)|0),
 density:clamp((regs[4]+1)/2,0,1),
 fractal:.35+gene(dna,420)*.62,
 glow:clamp((regs[8]+regs[25]+2)/4,0,1)
};
let music={tempo:48+((gene(dna,433)*132)|0),root:24+((gene(dna,449)*36)|0),scale:(family(dna)+((gene(dna,450)*8)|0))&7,timbre:gene(dna,465),harmony:clamp((regs[30]+1)/2,0,1),memory:clamp((regs[31]+1)/2,0,1)};
let architecture={nodes:4+((gene(dna,360)*28)|0),span:.2+gene(dna,365)*.8,vertical:clamp((regs[22]+regs[26]+2)/4,0,1),cistern:clamp((regs[23]+1)/2,0,1),nursery:clamp((regs[24]+1)/2,0,1),lantern:clamp((regs[25]+1)/2,0,1)};
let weather={rain:clamp((regs[11]+1)/2,0,1),wind:clamp((regs[14]+1)/2,0,1),heat:clamp((regs[9]+1)/2,0,1),cold:clamp((regs[10]+1)/2,0,1),drought:clamp((regs[12]+1)/2,0,1),frost:clamp((regs[13]+1)/2,0,1)};
let chemistry={soil:clamp((regs[0]+1)/2,0,1),water:clamp((regs[1]+1)/2,0,1),mineral:clamp((regs[15]+1)/2,0,1),microbe:clamp((regs[16]+1)/2,0,1),symbiosis:clamp((regs[17]+1)/2,0,1),allelopathy:clamp((regs[18]+1)/2,0,1)};
let checksum=0;for(let d=0;d<32;d++)checksum=M(checksum^Math.floor((regs[d]+2)*1e7)^d);
return {dna,name:dnaName(dna),hex:hex(dna),family:family(dna),phenotype:phen(dna),steps,regs,mem,domains,locusEnergy:Array.from(locusEnergy),visual,music,architecture,weather,chemistry,affinities,checksum:hex(checksum),context:ctx};}

// --- Expression parser for the tiny source language ---
function lexExpr(src){let t=[],i=0;while(i<src.length){let c=src[i];if(/\s/.test(c)){i++;continue}if(c==='"'||c==="'"){let q=c,s='',j=++i;while(i<src.length&&src[i]!==q){if(src[i]==='\\'&&i+1<src.length){let n=src[++i];s+=n==='n'?'\n':n==='t'?'\t':n==='e'?'\x1b':n}s+=src[i++]}i++;t.push({k:'str',v:s});continue}let m=src.slice(i).match(/^0x[0-9a-fA-F]+|^\d+(?:\.\d+)?/);if(m){t.push({k:'num',v:m[0].startsWith('0x')?parseInt(m[0],16):+m[0]});i+=m[0].length;continue}m=src.slice(i).match(/^[A-Za-z_][A-Za-z0-9_]*/);if(m){t.push({k:'id',v:m[0]});i+=m[0].length;continue}let two=src.slice(i,i+2);if(['<<','>>','&&','||','==','!=','<=','>='].includes(two)){t.push({k:'op',v:two});i+=2;continue}if('+-*/%&|^~!<>() ,'.includes(c)){t.push({k:c==='('? 'lp':c===')'?'rp':c===','?'comma':'op',v:c});i++;continue}throw Error('bad expression token '+c)}return t}
const PREC={'||':1,'&&':2,'|':3,'^':4,'&':5,'==':6,'!=':6,'<':7,'<=':7,'>':7,'>=':7,'<<':8,'>>':8,'+':9,'-':9,'*':10,'/':10,'%':10};
function evalExpr(src,env){let ts=lexExpr(src),p=0;function prim(){let x=ts[p++];if(!x)throw Error('expression ended');if(x.k==='num'||x.k==='str')return x.v;if(x.k==='op'&&['-','+','!','~'].includes(x.v)){let a=prim();return x.v==='-'?-a:x.v==='+'?+a:x.v==='!'?(!a?1:0):~a}if(x.k==='lp'){let v=expr(0);if(!ts[p]||ts[p++].k!=='rp')throw Error('missing )');return v}if(x.k==='id'){let id=x.v;if(ts[p]&&ts[p].k==='lp'){p++;let a=[];if(!ts[p]||ts[p].k!=='rp'){for(;;){a.push(expr(0));if(ts[p]&&ts[p].k==='comma'){p++;continue}break}}if(!ts[p]||ts[p++].k!=='rp')throw Error('missing ) after '+id);return callBuiltin(id,a,env)}if(id in env.vars)return env.vars[id];if(id in env.dna)return env.dna[id];if(id.toLowerCase() in env.context)return env.context[id.toLowerCase()];throw Error('unknown name '+id)}throw Error('bad expression')}
function expr(min){let a=prim();while(ts[p]&&ts[p].k==='op'&&(PREC[ts[p].v]||0)>=min){let op=ts[p].v,pr=PREC[op];p++;let b=expr(pr+1);switch(op){case'+':a=a+b;break;case'-':a=a-b;break;case'*':a=a*b;break;case'/':a=b?a/b:0;break;case'%':a=b?a%b:0;break;case'<<':a=a<<b;break;case'>>':a=a>>b;break;case'&':a=a&b;break;case'|':a=a|b;break;case'^':a=a^b;break;case'&&':a=a&&b?1:0;break;case'||':a=a||b?1:0;break;case'==':a=a==b?1:0;break;case'!=':a=a!=b?1:0;break;case'<':a=a<b?1:0;break;case'<=':a=a<=b?1:0;break;case'>':a=a>b?1:0;break;case'>=':a=a>=b?1:0;break}}return a}return expr(0)}
function callBuiltin(id,a,env){id=id.toLowerCase();if(id==='gene')return gene((a[0]>>>0),a[1]|0);if(id==='poly')return poly((a[0]>>>0),a[1]|0,a[2]===undefined?8:a[2]|0);if(id==='family')return family(a[0]>>>0);if(id==='mut')return mutate(a[0]>>>0,a[1]===undefined?.1:a[1],env.seed);if(id==='breed')return breed(a[0]>>>0,a[1]>>>0,env.seed,a[2]===undefined?.08:a[2]);if(id==='hash')return hashString(String(a[0]));if(id==='min')return Math.min(...a);if(id==='max')return Math.max(...a);if(id==='abs')return Math.abs(a[0]);if(id==='sin')return Math.sin(a[0]);if(id==='cos')return Math.cos(a[0]);if(id==='sqrt')return Math.sqrt(Math.max(0,a[0]));if(id==='clamp')return clamp(a[0],a[1]===undefined?0:a[1],a[2]===undefined?1:a[2]);if(id==='rand'){env.seed=M(env.seed);return env.seed/4294967296}throw Error('unknown function '+id)}
function statements(src){let out=[],buf='',q='',esc=false;for(let i=0;i<src.length;i++){let c=src[i];if(q){buf+=c;if(esc){esc=false;continue}if(c==='\\'){esc=true;continue}if(c===q)q='';continue}if(c==='"'||c==="'"){q=c;buf+=c;continue}if(c==='/'&&src[i+1]==='/'){while(i<src.length&&src[i]!='\n')i++;c='\n'}if(c===';'||c==='\n'){let z=buf.trim();if(z)out.push(z);buf='';continue}buf+=c}if(buf.trim())out.push(buf.trim());return out}
function compile(src){let ss=statements(src),code=[],labels={};for(let line=0;line<ss.length;line++){let s=ss[line].trim();if(s.endsWith(':')){labels[s.slice(0,-1).trim()]=code.length;continue}code.push({s,line:line+1})}return {code,labels,source:src}}
function parseQuoted(s){let m=s.match(/^(["'])([\s\S]*)\1$/);return m?m[2]:null}
function run(program,opts={}){if(typeof program==='string')program=compile(program);let env={vars:{},dna:{},context:Object.assign(defaultContext(),opts.context||{}),seed:(opts.seed===undefined?0x47414941:opts.seed)>>>0,last:null,bank:[],output:[],events:[]},pc=0,steps=0,max=opts.maxSteps||100000,on=opts.onEvent||(()=>{});function emit(type,data){let e={type,data,pc};env.events.push(e);on(e,env)}function value(s){return evalExpr(s,env)}while(pc<program.code.length&&steps++<max){let rec=program.code[pc],s=rec.s;try{
let m;if((m=s.match(/^seed\s+(.+)$/i))){env.seed=value(m[1])>>>0;pc++;continue}
if((m=s.match(/^context\s+([A-Za-z_]\w*)\s*=\s*(.+)$/i))){env.context[m[1].toLowerCase()]=+value(m[2]);pc++;continue}
if((m=s.match(/^(?:let|var)\s+([A-Za-z_]\w*)\s*=\s*(.+)$/i))){env.vars[m[1]]=value(m[2]);pc++;continue}
if((m=s.match(/^dna\s+([A-Za-z_]\w*)\s*=\s*family\s+(.+)$/i))){env.dna[m[1]]=atlasDNA(value(m[2])|0,env.seed);env.bank.push(m[1]);emit('dna',{name:m[1],dna:env.dna[m[1]]});pc++;continue}
if((m=s.match(/^dna\s+([A-Za-z_]\w*)\s*=\s*breed\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*)(?:\s+(.+))?$/i))){env.dna[m[1]]=breed(env.dna[m[2]]>>>0,env.dna[m[3]]>>>0,env.seed,m[4]?+value(m[4]):.08);env.bank.push(m[1]);emit('dna',{name:m[1],dna:env.dna[m[1]]});pc++;continue}
if((m=s.match(/^dna\s+([A-Za-z_]\w*)\s*=\s*mutate\s+([A-Za-z_]\w*)(?:\s+(.+))?$/i))){env.dna[m[1]]=mutate(env.dna[m[2]]>>>0,m[3]?+value(m[3]):.12,env.seed);env.bank.push(m[1]);emit('dna',{name:m[1],dna:env.dna[m[1]]});pc++;continue}
if((m=s.match(/^dna\s+([A-Za-z_]\w*)\s*=\s*word\s+(["'][\s\S]*["'])$/i))){let q=parseQuoted(m[2]);env.dna[m[1]]=M(hashString(q)^env.seed);env.bank.push(m[1]);emit('dna',{name:m[1],dna:env.dna[m[1]]});pc++;continue}
if((m=s.match(/^dna\s+([A-Za-z_]\w*)\s*=\s*(.+)$/i))){env.dna[m[1]]=value(m[2])>>>0;env.bank.push(m[1]);emit('dna',{name:m[1],dna:env.dna[m[1]]});pc++;continue}
if((m=s.match(/^([A-Za-z_]\w*)\s*=\s*(.+)$/))){env.vars[m[1]]=value(m[2]);pc++;continue}
if((m=s.match(/^breed\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*->\s*([A-Za-z_]\w*)(?:\s+(.+))?$/i))){env.dna[m[3]]=breed(env.dna[m[1]]>>>0,env.dna[m[2]]>>>0,env.seed,m[4]?+value(m[4]):.08);emit('dna',{name:m[3],dna:env.dna[m[3]]});pc++;continue}
if((m=s.match(/^mutate\s+([A-Za-z_]\w*)(?:\s+(.+?))?\s*->\s*([A-Za-z_]\w*)$/i))){env.dna[m[3]]=mutate(env.dna[m[1]]>>>0,m[2]?+value(m[2]):.12,env.seed);emit('dna',{name:m[3],dna:env.dna[m[3]]});pc++;continue}
if((m=s.match(/^express\s+([A-Za-z_]\w*)(?:\s+(.+))?$/i))){let d=env.dna[m[1]];if(d===undefined)throw Error('unknown DNA '+m[1]);env.last=express(d,m[2]?value(m[2])|0:8,env.context,env.last&&env.last.dna===d?env.last:null);emit('express',env.last);pc++;continue}
if((m=s.match(/^music\s+([A-Za-z_]\w*)(?:\s+(.+))?$/i))){let d=env.dna[m[1]];if(d===undefined)throw Error('unknown DNA '+m[1]);let ex=express(d,4,env.context);emit('music',{dna:d,beats:m[2]?value(m[2])|0:16,music:ex.music,expression:ex});pc++;continue}
if((m=s.match(/^lens\s+([A-Za-z_]\w*)(?:\s+(\d+))?(?:\s+(\d+))?$/i))){let d=env.dna[m[1]];if(d===undefined)throw Error('unknown DNA '+m[1]);let start=m[2]?+m[2]:0,count=m[3]?+m[3]:16,a=[];for(let l=start;l<Math.min(512,start+count);l++)a.push({locus:l,domain:GDOM[l>>4],operator:GOP[l&15],value:gene(d,l)});emit('lens',{name:m[1],dna:d,loci:a});pc++;continue}
if((m=s.match(/^atlas(?:\s+(.+))?$/i))){emit('atlas',{page:m[1]?value(m[1])|0:0,seed:env.seed});pc++;continue}
if((m=s.match(/^emit\s+([A-Za-z_]\w*)$/i))){let d=env.dna[m[1]];if(d===undefined)throw Error('unknown DNA '+m[1]);let z={name:m[1],dna:d,hex:hex(d),family:family(d),dnaName:dnaName(d),phenotype:phen(d)};env.output.push(JSON.stringify(z));emit('print',z);pc++;continue}
if((m=s.match(/^print\s+(.+)$/i))){let v=value(m[1]);env.output.push(String(v));emit('print',v);pc++;continue}
if((m=s.match(/^if\s+(.+)\s+goto\s+([A-Za-z_]\w*)$/i))){if(value(m[1])){if(program.labels[m[2]]===undefined)throw Error('unknown label '+m[2]);pc=program.labels[m[2]]}else pc++;continue}
if((m=s.match(/^goto\s+([A-Za-z_]\w*)$/i))){if(program.labels[m[1]]===undefined)throw Error('unknown label '+m[1]);pc=program.labels[m[1]];continue}
if(/^halt$/i.test(s)){emit('halt',null);break}
throw Error('unknown statement: '+s)
}catch(e){e.message='line '+rec.line+': '+e.message;throw e}}
if(steps>=max)throw Error('step limit');return env}
return {VERSION:'0.1',LOC,FAM,GDOM,GOP,PH,AGENTS,M,hashString,tr,gene,poly,family,atlasDNA,dnaName,hex,phen,mutate,breed,defaultContext,express,evalExpr,compile,run};
});
