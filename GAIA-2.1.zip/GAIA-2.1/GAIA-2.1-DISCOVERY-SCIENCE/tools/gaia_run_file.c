#include "../uefi/gaia_machine_core.h"
#include <stdio.h>
#include <stdlib.h>
static void o(void*c,const char*s){(void)c;fputs(s,stdout);}
static void pc(void*c,char x){(void)c;fputc(x,stdout);}
static void* al(void*c,d_u64 n){(void)c;return calloc(1,(size_t)n);}
static void fr(void*c,void*p){(void)c;free(p);}
static d_u64 ap(void*c,const char*d,const char*n){(void)c;(void)d;(void)n;return 0;}
static d_u64 rt(void*c,const char*path){(void)c;FILE*f=fopen(path,"rb");if(!f)return 0;if(fseek(f,0,SEEK_END)){fclose(f);return 0;}long n=ftell(f);if(n<0||n>16777216){fclose(f);return 0;}rewind(f);char*s=(char*)malloc((size_t)n+1);if(!s){fclose(f);return 0;}if(fread(s,1,(size_t)n,f)!=(size_t)n){fclose(f);free(s);return 0;}fclose(f);s[n]=0;return (d_u64)(void*)s;}
int main(int argc,char**argv){
 if(argc!=2){fprintf(stderr,"usage: %s file.gaia\n",argv[0]);return 64;}
 FILE*f=fopen(argv[1],"rb");if(!f){perror("open");return 65;}
 fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char*s=malloc((size_t)n+1);if(!s)return 66;
 if(fread(s,1,(size_t)n,f)!=(size_t)n){fclose(f);free(s);return 67;}fclose(f);s[n]=0;
 D3Program p;D3VM v;D3Host h={o,pc,al,fr,ap,0,0,0,rt};
 if(!d3_compile(&p,s)){fprintf(stderr,"COMPILE FAIL line %d: %s\n",p.error_line,p.error);free(s);return 1;}
 if(!d3_run(&p,&h,&v,1000000)){fprintf(stderr,"VM FAIL: %s\n",v.error_text);free(s);return 2;}
 free(s);return 0;
}
