#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
CC=${CC:-clang}
$CC -O2 -Wall -Wextra tools/gaia_run_file.c -o tools/gaia_run_file
$CC -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined tools/gaia_run_file.c -o tools/gaia_run_file_san
$CC -O2 -Wall -Wextra tools/gaia_opencl_runner.c -ldl -o tools/gaia_opencl_runner
n=0
for src in science/examples/*.gaia; do
  base=$(basename "$src" .gaia)
  expected="science/tests/$base.out"
  tmp=$(mktemp)
  tools/gaia_run_file "$src" > "$tmp"
  cmp "$tmp" "$expected"
  ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 tools/gaia_run_file_san "$src" >/dev/null
  rm -f "$tmp"
  n=$((n+1))
  echo "SCIENCE PASS $base"
done
# GPU/OpenCL path has device-dependent backend selection, but numerical semantics must match CPU.
tmp=$(mktemp)
tools/gaia_opencl_runner science/examples/09_gpu_axpy.gaia > "$tmp"
cmp "$tmp" science/tests/09_gpu_axpy.out
rm -f "$tmp"
echo "OPENCL ADAPTER PASS // GPU if available, CPU-identical fallback otherwise"
echo "GAIA 2.1 SCIENCE TESTS PASS // $n programs // native + ASAN + UBSAN"
