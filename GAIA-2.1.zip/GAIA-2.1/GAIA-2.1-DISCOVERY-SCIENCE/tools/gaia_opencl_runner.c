#include "../uefi/gaia_machine_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <dlfcn.h>

/* Tiny dynamically-loaded OpenCL 1.2 adapter. No OpenCL headers or link-time dependency required. */
typedef int cl_int; typedef unsigned int cl_uint; typedef unsigned long cl_ulong; typedef cl_ulong cl_bitfield; typedef cl_bitfield cl_device_type; typedef cl_bitfield cl_mem_flags; typedef cl_uint cl_bool; typedef intptr_t cl_context_properties; typedef intptr_t cl_queue_properties;
typedef struct _cl_platform_id* cl_platform_id; typedef struct _cl_device_id* cl_device_id; typedef struct _cl_context* cl_context; typedef struct _cl_command_queue* cl_command_queue; typedef struct _cl_mem* cl_mem; typedef struct _cl_program* cl_program; typedef struct _cl_kernel* cl_kernel; typedef struct _cl_event* cl_event;
#define CL_SUCCESS 0
#define CL_TRUE 1
#define CL_DEVICE_TYPE_GPU (1ULL<<2)
#define CL_MEM_READ_WRITE (1ULL<<0)
#define CL_MEM_READ_ONLY (1ULL<<2)
#define CL_MEM_COPY_HOST_PTR (1ULL<<5)

typedef cl_int (*PFN_clGetPlatformIDs)(cl_uint,cl_platform_id*,cl_uint*);
typedef cl_int (*PFN_clGetDeviceIDs)(cl_platform_id,cl_device_type,cl_uint,cl_device_id*,cl_uint*);
typedef cl_context (*PFN_clCreateContext)(const cl_context_properties*,cl_uint,const cl_device_id*,void*,void*,cl_int*);
typedef cl_command_queue (*PFN_clCreateCommandQueue)(cl_context,cl_device_id,cl_bitfield,cl_int*);
typedef cl_program (*PFN_clCreateProgramWithSource)(cl_context,cl_uint,const char**,const size_t*,cl_int*);
typedef cl_int (*PFN_clBuildProgram)(cl_program,cl_uint,const cl_device_id*,const char*,void*,void*);
typedef cl_kernel (*PFN_clCreateKernel)(cl_program,const char*,cl_int*);
typedef cl_mem (*PFN_clCreateBuffer)(cl_context,cl_mem_flags,size_t,void*,cl_int*);
typedef cl_int (*PFN_clSetKernelArg)(cl_kernel,cl_uint,size_t,const void*);
typedef cl_int (*PFN_clEnqueueNDRangeKernel)(cl_command_queue,cl_kernel,cl_uint,const size_t*,const size_t*,const size_t*,cl_uint,const cl_event*,cl_event*);
typedef cl_int (*PFN_clEnqueueReadBuffer)(cl_command_queue,cl_mem,cl_bool,size_t,size_t,void*,cl_uint,const cl_event*,cl_event*);
typedef cl_int (*PFN_clFinish)(cl_command_queue);
typedef cl_int (*PFN_clReleaseMemObject)(cl_mem); typedef cl_int (*PFN_clReleaseKernel)(cl_kernel); typedef cl_int (*PFN_clReleaseProgram)(cl_program); typedef cl_int (*PFN_clReleaseCommandQueue)(cl_command_queue); typedef cl_int (*PFN_clReleaseContext)(cl_context);

typedef struct {
 void*lib; cl_platform_id platform; cl_device_id device; int checked,available;
 PFN_clGetPlatformIDs GetPlatformIDs; PFN_clGetDeviceIDs GetDeviceIDs; PFN_clCreateContext CreateContext; PFN_clCreateCommandQueue CreateCommandQueue; PFN_clCreateProgramWithSource CreateProgramWithSource; PFN_clBuildProgram BuildProgram; PFN_clCreateKernel CreateKernel; PFN_clCreateBuffer CreateBuffer; PFN_clSetKernelArg SetKernelArg; PFN_clEnqueueNDRangeKernel EnqueueNDRangeKernel; PFN_clEnqueueReadBuffer EnqueueReadBuffer; PFN_clFinish Finish; PFN_clReleaseMemObject ReleaseMemObject; PFN_clReleaseKernel ReleaseKernel; PFN_clReleaseProgram ReleaseProgram; PFN_clReleaseCommandQueue ReleaseCommandQueue; PFN_clReleaseContext ReleaseContext;
} OCL;

#define LOAD(S,N) do{(S)->N=(PFN_cl##N)dlsym((S)->lib,"cl" #N);if(!(S)->N)return 0;}while(0)
static int ocl_init(OCL*s){
 if(s->checked)return s->available;s->checked=1;s->lib=dlopen("libOpenCL.so.1",RTLD_LAZY|RTLD_LOCAL);if(!s->lib)return 0;
 LOAD(s,GetPlatformIDs);LOAD(s,GetDeviceIDs);LOAD(s,CreateContext);LOAD(s,CreateCommandQueue);LOAD(s,CreateProgramWithSource);LOAD(s,BuildProgram);LOAD(s,CreateKernel);LOAD(s,CreateBuffer);LOAD(s,SetKernelArg);LOAD(s,EnqueueNDRangeKernel);LOAD(s,EnqueueReadBuffer);LOAD(s,Finish);LOAD(s,ReleaseMemObject);LOAD(s,ReleaseKernel);LOAD(s,ReleaseProgram);LOAD(s,ReleaseCommandQueue);LOAD(s,ReleaseContext);
 cl_uint np=0;if(s->GetPlatformIDs(0,0,&np)!=CL_SUCCESS||!np)return 0;cl_platform_id*p=(cl_platform_id*)calloc(np,sizeof(*p));if(!p)return 0;if(s->GetPlatformIDs(np,p,0)!=CL_SUCCESS){free(p);return 0;}
 for(cl_uint i=0;i<np;i++){cl_device_id d=0;if(s->GetDeviceIDs(p[i],CL_DEVICE_TYPE_GPU,1,&d,0)==CL_SUCCESS&&d){s->platform=p[i];s->device=d;s->available=1;break;}}free(p);return s->available;
}
#undef LOAD

static int gpu_available(void*ctx){return ocl_init((OCL*)ctx);}
static int gpu_axpy(void*ctx,void*vy,d_u64 abits,void*vx){
 OCL*s=(OCL*)ctx;G21Tensor*y=(G21Tensor*)vy,*x=(G21Tensor*)vx;if(!ocl_init(s)||!g21_tensor_ok(y)||!g21_tensor_ok(x)||y->len!=x->len)return 0;
 static const char*src="#pragma OPENCL EXTENSION cl_khr_fp64 : enable\n__kernel void axpy(__global double*y,double a,__global const double*x,ulong n){size_t i=get_global_id(0);if(i<n)y[i]+=a*x[i];}";
 cl_int e=0;cl_context c=s->CreateContext(0,1,&s->device,0,0,&e);if(!c||e)return 0;cl_command_queue q=s->CreateCommandQueue(c,s->device,0,&e);if(!q||e){s->ReleaseContext(c);return 0;}
 cl_program p=s->CreateProgramWithSource(c,1,&src,0,&e);if(!p||e||s->BuildProgram(p,1,&s->device,0,0,0)!=CL_SUCCESS){if(p)s->ReleaseProgram(p);s->ReleaseCommandQueue(q);s->ReleaseContext(c);return 0;}
 cl_kernel k=s->CreateKernel(p,"axpy",&e);size_t bytes=(size_t)y->len*sizeof(double);cl_mem my=0,mx=0;if(k&&e==CL_SUCCESS){my=s->CreateBuffer(c,CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR,bytes,g21_tdata(y),&e);if(my&&e==CL_SUCCESS)mx=s->CreateBuffer(c,CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR,bytes,g21_tdata(x),&e);}
 int ok=0;if(k&&my&&mx&&e==CL_SUCCESS){double a=g21_f64(abits);cl_ulong n=(cl_ulong)y->len;e=s->SetKernelArg(k,0,sizeof(my),&my);if(!e)e=s->SetKernelArg(k,1,sizeof(a),&a);if(!e)e=s->SetKernelArg(k,2,sizeof(mx),&mx);if(!e)e=s->SetKernelArg(k,3,sizeof(n),&n);size_t global=(size_t)y->len;if(!e)e=s->EnqueueNDRangeKernel(q,k,1,0,&global,0,0,0,0);if(!e)e=s->Finish(q);if(!e)e=s->EnqueueReadBuffer(q,my,CL_TRUE,0,bytes,g21_tdata(y),0,0,0);ok=(e==CL_SUCCESS);}
 if(mx)s->ReleaseMemObject(mx);if(my)s->ReleaseMemObject(my);if(k)s->ReleaseKernel(k);s->ReleaseProgram(p);s->ReleaseCommandQueue(q);s->ReleaseContext(c);return ok;
}

static void o(void*c,const char*s){(void)c;fputs(s,stdout);} static void pc(void*c,char x){(void)c;fputc(x,stdout);} static void* al(void*c,d_u64 n){(void)c;return calloc(1,(size_t)n);} static void fr(void*c,void*p){(void)c;free(p);} static d_u64 ap(void*c,const char*d,const char*n){(void)c;(void)d;(void)n;return 0;}
static d_u64 rt(void*c,const char*path){(void)c;FILE*f=fopen(path,"rb");if(!f)return 0;fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);if(n<0||n>16777216){fclose(f);return 0;}char*s=(char*)malloc((size_t)n+1);if(!s){fclose(f);return 0;}if(fread(s,1,(size_t)n,f)!=(size_t)n){fclose(f);free(s);return 0;}fclose(f);s[n]=0;return (d_u64)(void*)s;}
int main(int argc,char**argv){if(argc!=2){fprintf(stderr,"usage: %s file.gaia\n",argv[0]);return 64;}FILE*f=fopen(argv[1],"rb");if(!f){perror("open");return 65;}fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char*srcbuf=(char*)malloc((size_t)n+1);if(!srcbuf)return 66;if(fread(srcbuf,1,(size_t)n,f)!=(size_t)n){fclose(f);free(srcbuf);return 67;}fclose(f);srcbuf[n]=0;OCL state={0};D3Program p;D3VM v;D3Host h={o,pc,al,fr,ap,&state,gpu_axpy,gpu_available,rt};if(!d3_compile(&p,srcbuf)){fprintf(stderr,"COMPILE FAIL line %d: %s\n",p.error_line,p.error);free(srcbuf);return 1;}if(!d3_run(&p,&h,&v,1000000)){fprintf(stderr,"VM FAIL: %s\n",v.error_text);free(srcbuf);return 2;}free(srcbuf);if(state.lib)dlclose(state.lib);return 0;}
