#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),G=require('./gaia_core.js');
function help(){console.log(`GAIA ${G.VERSION} // PLEOMORPHIC DNA PROGRAMMING\n\nusage:\n  node gaia.js file.gaia\n  node gaia.js --dna 137\n  node gaia.js --lens 137 0 16\n  node gaia.js --repl\n`)}
function showExpression(ex){console.log(`DNA ${ex.name} // ${ex.hex} // FAMILY ${ex.family}/511`);console.log(ex.phenotype);console.log(`CHECKSUM ${ex.checksum} // TEMPO ${ex.music.tempo} // ARCH NODES ${ex.architecture.nodes}`)}
function execute(src){return G.run(src,{onEvent:e=>{if(e.type==='print')console.log(typeof e.data==='object'?JSON.stringify(e.data,null,2):e.data);if(e.type==='express')showExpression(e.data);if(e.type==='lens')for(const q of e.data.loci)console.log(`L${String(q.locus).padStart(3,'0')} ${q.domain}/${q.operator} ${(q.value*100).toFixed(1)}%`);if(e.type==='atlas'){let st=(e.data.page&31)*16;for(let f=st;f<st+16;f++){let d=G.atlasDNA(f,e.data.seed);console.log(`F${String(f).padStart(3,'0')} ${G.dnaName(d)} ${G.hex(d)} ${G.phen(d)}`)}}}})}
const a=process.argv.slice(2);if(!a.length){help();process.exit(0)}
if(a[0]==='--dna'){let f=+(a[1]||0),d=G.atlasDNA(f);showExpression(G.express(d,8));process.exit(0)}
if(a[0]==='--lens'){let f=+(a[1]||0),st=+(a[2]||0),n=+(a[3]||16),d=G.atlasDNA(f);for(let l=st;l<Math.min(512,st+n);l++)console.log(`L${String(l).padStart(3,'0')} ${G.GDOM[l>>4]}/${G.GOP[l&15]} ${(G.gene(d,l)*100).toFixed(1)}%`);process.exit(0)}
if(a[0]==='--repl'){
 const readline=require('readline'),rl=readline.createInterface({input:process.stdin,output:process.stdout,prompt:'Gaia> '});let buf='';console.log('GAIA // type .run, .clear, .quit');rl.prompt();rl.on('line',line=>{if(line==='.quit')return rl.close();if(line==='.clear'){buf='';console.log('cleared');rl.prompt();return}if(line==='.run'){try{execute(buf)}catch(e){console.error('GAIA FAULT // '+e.message)}rl.prompt();return}buf+=line+'\n';rl.prompt()});
}else{let file=a[0],src=fs.readFileSync(file,'utf8');try{execute(src)}catch(e){console.error('GAIA FAULT // '+e.message);process.exit(1)}}
