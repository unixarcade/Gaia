#!/usr/bin/env python3
"""Build a tiny FAT12 EFI System Partition and El Torito UEFI ISO with stdlib only."""
from __future__ import annotations
import struct, sys, math
from pathlib import Path

SECTOR=512
ISO_SECTOR=2048
FAT_SECTORS=9
ROOT_ENTRIES=224
ROOT_SECTORS=(ROOT_ENTRIES*32 + SECTOR-1)//SECTOR
DATA_START=1+2*FAT_SECTORS+ROOT_SECTORS
TOTAL_SECTORS=2880

def fat12_set(fat: bytearray, cluster:int, value:int)->None:
    off=cluster + cluster//2
    value &= 0xFFF
    if cluster & 1:
        fat[off]=(fat[off]&0x0F)|((value<<4)&0xF0)
        fat[off+1]=(value>>4)&0xFF
    else:
        fat[off]=value&0xFF
        fat[off+1]=(fat[off+1]&0xF0)|((value>>8)&0x0F)

def dirent(name11:bytes, attr:int, cluster:int, size:int=0)->bytes:
    if len(name11)!=11: raise ValueError(name11)
    b=bytearray(32); b[:11]=name11; b[11]=attr
    struct.pack_into('<H',b,26,cluster)
    struct.pack_into('<I',b,28,size)
    return bytes(b)

def cluster_offset(c:int)->int:
    return (DATA_START + (c-2))*SECTOR

def make_fat12(efi:bytes)->bytes:
    img=bytearray(TOTAL_SECTORS*SECTOR)
    bs=img[:SECTOR]
    bs[0:3]=b'\xEB\x3C\x90'; bs[3:11]=b'GAIA21SC'
    struct.pack_into('<H',bs,11,SECTOR); bs[13]=1
    struct.pack_into('<H',bs,14,1); bs[16]=2
    struct.pack_into('<H',bs,17,ROOT_ENTRIES); struct.pack_into('<H',bs,19,TOTAL_SECTORS)
    bs[21]=0xF0; struct.pack_into('<H',bs,22,FAT_SECTORS); struct.pack_into('<H',bs,24,18); struct.pack_into('<H',bs,26,2)
    struct.pack_into('<I',bs,28,0); struct.pack_into('<I',bs,32,0)
    bs[36]=0; bs[37]=0; bs[38]=0x29; struct.pack_into('<I',bs,39,0x47414941)
    bs[43:54]=b'GAIA21 ESP '; bs[54:62]=b'FAT12   '; bs[510:512]=b'\x55\xAA'
    img[:SECTOR]=bs

    file_clusters=max(1, math.ceil(len(efi)/SECTOR))
    first_file=4
    last_file=first_file+file_clusters-1
    max_cluster=(TOTAL_SECTORS-DATA_START)+1
    if last_file>max_cluster: raise ValueError('EFI too large for 1.44MB ESP')

    fat=bytearray(FAT_SECTORS*SECTOR); fat[0:3]=b'\xF0\xFF\xFF'
    fat12_set(fat,2,0xFFF); fat12_set(fat,3,0xFFF)
    for c in range(first_file,last_file+1): fat12_set(fat,c,0xFFF if c==last_file else c+1)
    off=SECTOR; img[off:off+len(fat)]=fat
    off=SECTOR*(1+FAT_SECTORS); img[off:off+len(fat)]=fat

    root_off=SECTOR*(1+2*FAT_SECTORS)
    img[root_off:root_off+32]=dirent(b'EFI        ',0x10,2)
    efi_dir=bytearray(SECTOR)
    efi_dir[0:32]=dirent(b'.          ',0x10,2)
    efi_dir[32:64]=dirent(b'..         ',0x10,0)
    efi_dir[64:96]=dirent(b'BOOT       ',0x10,3)
    img[cluster_offset(2):cluster_offset(2)+SECTOR]=efi_dir
    boot_dir=bytearray(SECTOR)
    boot_dir[0:32]=dirent(b'.          ',0x10,3)
    boot_dir[32:64]=dirent(b'..         ',0x10,2)
    boot_dir[64:96]=dirent(b'BOOTX64 EFI',0x20,first_file,len(efi))
    img[cluster_offset(3):cluster_offset(3)+SECTOR]=boot_dir
    img[cluster_offset(first_file):cluster_offset(first_file)+len(efi)]=efi
    return bytes(img)

def both16(n:int)->bytes: return struct.pack('<H',n)+struct.pack('>H',n)
def both32(n:int)->bytes: return struct.pack('<I',n)+struct.pack('>I',n)

def dir_record(extent:int,size:int,ident:bytes,flags:int)->bytes:
    l=33+len(ident)+(1 if len(ident)%2==0 else 0)
    b=bytearray(l); b[0]=l; b[1]=0; b[2:10]=both32(extent); b[10:18]=both32(size)
    b[18:25]=bytes([126,8,17,0,0,0,0]) # 2026-08-17 00:00:00 GMT
    b[25]=flags; b[26]=0; b[27]=0; b[28:32]=both16(1); b[32]=len(ident); b[33:33+len(ident)]=ident
    return bytes(b)

def make_iso(esp:bytes)->bytes:
    CAT=19; PTL=20; PTM=21; ROOT=22; BOOT=23
    boot_secs=math.ceil(len(esp)/ISO_SECTOR)
    total=BOOT+boot_secs
    iso=bytearray(total*ISO_SECTOR)
    # Primary Volume Descriptor
    p=memoryview(iso)[16*ISO_SECTOR:17*ISO_SECTOR]; p[0]=1;p[1:6]=b'CD001';p[6]=1
    p[8:40]=b'GAIA SCIENCE'.ljust(32,b' '); p[40:72]=b'GAIA_SCIENCE'.ljust(32,b' '); p[80:88]=both32(total)
    p[120:124]=both16(1);p[124:128]=both16(1);p[128:132]=both16(ISO_SECTOR)
    p[132:140]=both32(10); struct.pack_into('<I',p,140,PTL); struct.pack_into('<I',p,144,0); struct.pack_into('>I',p,148,PTM); struct.pack_into('>I',p,152,0)
    rr=dir_record(ROOT,ISO_SECTOR,b'\x00',2); p[156:156+len(rr)]=rr
    p[190:318]=b'GAIA 2.1 SCIENCE UEFI'.ljust(128,b' '); p[318:446]=b'LUMINOSITY + GPTEUS'.ljust(128,b' ')
    p[446:574]=b'GAIA 2.1 SCIENCE'.ljust(128,b' ')
    p[881]=1
    # Boot Record Volume Descriptor
    b=memoryview(iso)[17*ISO_SECTOR:18*ISO_SECTOR]; b[0]=0;b[1:6]=b'CD001';b[6]=1;b[7:39]=b'EL TORITO SPECIFICATION'.ljust(32,b' '); struct.pack_into('<I',b,71,CAT)
    # Volume descriptor terminator
    t=memoryview(iso)[18*ISO_SECTOR:19*ISO_SECTOR]; t[0]=255;t[1:6]=b'CD001';t[6]=1
    # El Torito boot catalog, UEFI platform 0xEF
    c=bytearray(ISO_SECTOR); c[0]=1;c[1]=0xEF;c[4:28]=b'GAIA 2.1 SCIENCE'.ljust(24,b' ');c[30]=0x55;c[31]=0xAA
    words=list(struct.unpack('<16H',c[:32])); words[14]=0; checksum=(-sum(words))&0xFFFF; struct.pack_into('<H',c,28,checksum)
    c[32]=0x88;c[33]=0x00;struct.pack_into('<H',c,34,0);c[36]=0;c[37]=0;struct.pack_into('<H',c,38,len(esp)//512);struct.pack_into('<I',c,40,BOOT)
    iso[CAT*ISO_SECTOR:(CAT+1)*ISO_SECTOR]=c
    # little/big path tables: root only
    pl=bytearray(ISO_SECTOR);pl[0]=1;pl[1]=0;struct.pack_into('<I',pl,2,ROOT);struct.pack_into('<H',pl,6,1);pl[8]=0
    pm=bytearray(ISO_SECTOR);pm[0]=1;pm[1]=0;struct.pack_into('>I',pm,2,ROOT);struct.pack_into('>H',pm,6,1);pm[8]=0
    iso[PTL*ISO_SECTOR:(PTL+1)*ISO_SECTOR]=pl; iso[PTM*ISO_SECTOR:(PTM+1)*ISO_SECTOR]=pm
    # root directory records
    rd=bytearray(ISO_SECTOR); dot=dir_record(ROOT,ISO_SECTOR,b'\x00',2); dd=dir_record(ROOT,ISO_SECTOR,b'\x01',2);rd[:len(dot)]=dot;rd[len(dot):len(dot)+len(dd)]=dd
    iso[ROOT*ISO_SECTOR:(ROOT+1)*ISO_SECTOR]=rd
    iso[BOOT*ISO_SECTOR:BOOT*ISO_SECTOR+len(esp)]=esp
    return bytes(iso)

def verify(esp:bytes,iso:bytes)->None:
    assert esp[510:512]==b'\x55\xAA' and esp[54:62]==b'FAT12   '
    assert b'BOOTX64 EFI' in esp
    p=iso[16*ISO_SECTOR:17*ISO_SECTOR]; assert p[:7]==b'\x01CD001\x01'
    b=iso[17*ISO_SECTOR:18*ISO_SECTOR]; assert b[7:30].startswith(b'EL TORITO SPECIFICATION')
    c=iso[19*ISO_SECTOR:20*ISO_SECTOR]; assert c[0]==1 and c[1]==0xEF and c[30:32]==b'\x55\xAA' and c[32]==0x88
    assert sum(struct.unpack('<16H',c[:32]))&0xFFFF==0
    assert struct.unpack_from('<I',c,40)[0]==23

def main():
    if len(sys.argv)!=4: raise SystemExit('usage: make_uefi_iso.py BOOTX64.EFI OUT.iso OUT-esp.img')
    efi=Path(sys.argv[1]).read_bytes(); esp=make_fat12(efi); iso=make_iso(esp); verify(esp,iso)
    Path(sys.argv[2]).write_bytes(iso);Path(sys.argv[3]).write_bytes(esp)
    print(f'ESP {len(esp)} bytes // ISO {len(iso)} bytes // EFI {len(efi)} bytes')
if __name__=='__main__': main()
