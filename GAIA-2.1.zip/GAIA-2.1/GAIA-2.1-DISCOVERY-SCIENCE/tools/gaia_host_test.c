#include "../uefi/gaia_machine_core.h"
#include <stdio.h>
#include <stdlib.h>
static void o(void*c,const char*s){(void)c;fputs(s,stdout);}static void pc(void*c,char x){(void)c;fputc(x,stdout);}static void* al(void*c,d_u64 n){(void)c;return malloc((size_t)n);}static void fr(void*c,void*p){(void)c;free(p);}static d_u64 ap(void*c,const char*d,const char*n){(void)c;(void)d;(void)n;return 0;}
int main(void){const char*s="dna a=family(137,53); dna b=family(11,53); dna c=breed(a,b,600,5300); printhex(c); println(\"\"); println(gene(c,448)); ptr p=alloc(16); poke64(p,c); println(peek64(p)); free(p); halt;";D3Program p;D3VM v;D3Host h={o,pc,al,fr,ap,0,0,0,0};if(!d3_compile(&p,s)){printf("COMPILE FAIL %d %s\n",p.error_line,p.error);return 1;}if(!d3_run(&p,&h,&v,100000)){printf("VM FAIL %s\n",v.error_text);return 2;}puts("GAIA SYSTEMS HOST TEST PASS");return 0;}
