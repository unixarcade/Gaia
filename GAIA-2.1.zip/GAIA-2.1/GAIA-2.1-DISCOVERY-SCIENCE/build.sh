#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
make clean
make CC=clang LD=lld-link
make test CC=clang
make iso CC=clang LD=lld-link
file BOOTX64.EFI GAIA-2.1-SCIENCE-UEFI.iso gaia-science-esp.img
sha256sum BOOTX64.EFI GAIA-2.1-SCIENCE-UEFI.iso gaia-science-esp.img > SHA256.txt
python3 tools/verify_release.py | tee VERIFICATION.txt
cat SHA256.txt
