#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

CC=${CC:-clang}
$CC -O2 -Wall -Wextra tools/gaia_run_file.c -o tools/gaia_run_file
$CC -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined tools/gaia_run_file.c -o tools/gaia_run_file_san

n=0
for src in discovery/examples/*.gaia; do
  base=$(basename "$src" .gaia)
  expected="discovery/tests/$base.out"
  tmp=$(mktemp)
  tools/gaia_run_file "$src" > "$tmp"
  cmp "$tmp" "$expected"
  ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 tools/gaia_run_file_san "$src" >/dev/null
  rm -f "$tmp"
  n=$((n+1))
  echo "PASS $base"
done

echo "GAIA 2 DISCOVERY TESTS PASS // $n programs // native + ASAN + UBSAN"
